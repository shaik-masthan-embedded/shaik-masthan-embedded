"""
test_can_frame.py
Unit tests for CAN frame encoding, decoding, and signal extraction.
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../src/can"))

import pytest
from can_frame import CANFrame, CANSignal, CAN_FRAME_STD, CAN_FRAME_EXT


# ─────────────────────────────────────────────
# CANFrame Tests
# ─────────────────────────────────────────────
class TestCANFrame:

    def test_standard_frame_creation(self):
        frame = CANFrame(arbitration_id=0x0C0, data=bytes([0x01, 0x02, 0x03]))
        assert frame.arbitration_id == 0x0C0
        assert frame.dlc == 3
        assert frame.is_standard is True

    def test_extended_frame_creation(self):
        frame = CANFrame(arbitration_id=0x1FFFFFFF, data=b'\xFF',
                         frame_type=CAN_FRAME_EXT)
        assert frame.frame_type == CAN_FRAME_EXT
        assert frame.dlc == 1

    def test_invalid_standard_id(self):
        with pytest.raises(ValueError):
            CANFrame(arbitration_id=0x800, data=b'\x00')  # > 0x7FF

    def test_data_too_long(self):
        with pytest.raises(ValueError):
            CANFrame(arbitration_id=0x100, data=bytes(9))  # 9 bytes > 8

    def test_encode_decode_roundtrip(self):
        original = CANFrame(arbitration_id=0x1A0,
                            data=bytes([0xDE, 0xAD, 0xBE, 0xEF, 0x01, 0x02]))
        raw      = original.to_bytes()
        decoded  = CANFrame.from_bytes(raw)

        assert decoded.arbitration_id == original.arbitration_id
        assert decoded.data           == original.data
        assert decoded.dlc            == original.dlc

    def test_dlc_correct(self):
        frame = CANFrame(arbitration_id=0x100, data=bytes([0, 1, 2, 3, 4, 5, 6, 7]))
        assert frame.dlc == 8

    def test_empty_data(self):
        frame = CANFrame(arbitration_id=0x100, data=b'')
        assert frame.dlc == 0

    def test_str_representation(self):
        frame = CANFrame(arbitration_id=0x0C0, data=bytes([0xAB, 0xCD]))
        s = str(frame)
        assert "0x0C0" in s
        assert "AB CD" in s


# ─────────────────────────────────────────────
# CANSignal Tests
# ─────────────────────────────────────────────
class TestCANSignal:

    def test_decode_engine_rpm(self):
        # EngineRPM: start_bit=0, length=16, factor=0.25
        # Raw value 10000 → 10000 * 0.25 = 2500 rpm
        sig  = CANSignal("EngineRPM", 0, 16, factor=0.25, offset=0,
                         min_val=0, max_val=16383.75, unit="rpm")
        raw  = (10000).to_bytes(8, "little")
        val  = sig.decode(raw)
        assert val == 2500.0

    def test_decode_engine_temp(self):
        # EngineTemp: start_bit=16, length=8, factor=1, offset=-40
        # Raw=130 → 130 - 40 = 90°C
        sig  = CANSignal("EngineTemp", 16, 8, factor=1.0, offset=-40,
                         min_val=-40, max_val=215, unit="°C")
        data = bytearray(8)
        data[2] = 130  # byte 2 = bits 16-23
        val  = sig.decode(bytes(data))
        assert val == 90.0

    def test_encode_decode_roundtrip(self):
        sig = CANSignal("Speed", 0, 16, factor=0.01, offset=0,
                        min_val=0, max_val=655.35, unit="km/h")
        physical = 80.0
        raw      = sig.encode(physical)
        data     = raw.to_bytes(8, "little")
        decoded  = sig.decode(data)
        assert abs(decoded - physical) < 0.02  # within factor precision

    def test_signal_min_value(self):
        sig  = CANSignal("Gear", 0, 4, factor=1.0, offset=0,
                         min_val=0, max_val=8, unit="")
        data = bytes(8)
        val  = sig.decode(data)
        assert val == 0.0

    def test_signal_max_value(self):
        sig  = CANSignal("Gear", 0, 4, factor=1.0, offset=0,
                         min_val=0, max_val=8, unit="")
        raw  = (0xF).to_bytes(8, "little")
        val  = sig.decode(raw)
        assert val == 15.0


# ─────────────────────────────────────────────
# Run
# ─────────────────────────────────────────────
if __name__ == "__main__":
    pytest.main([__file__, "-v"])
