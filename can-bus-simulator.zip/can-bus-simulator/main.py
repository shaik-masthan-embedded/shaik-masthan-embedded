"""
main.py
CAN Bus Simulator — Main entry point.
Simulates automotive CAN traffic, validates signals, generates reports.

Usage:
    python main.py                        # default 2s simulation
    python main.py --duration 5           # 5 second simulation
    python main.py --duration 3 --verbose # show every frame
"""

import sys
import os
import argparse

# Add src directories to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src/can"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src/reports"))

from can_bus          import CANBus
from can_validator    import CANValidator
from report_generator import export_json, export_html


def main():
    parser = argparse.ArgumentParser(description="CAN Bus Simulator & Validator")
    parser.add_argument("--duration", type=float, default=2.0,
                        help="Simulation duration in seconds (default: 2.0)")
    parser.add_argument("--verbose", action="store_true",
                        help="Print every CAN frame as it's transmitted")
    parser.add_argument("--output-dir", default="reports",
                        help="Directory for reports (default: reports/)")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    print("=" * 60)
    print(" CAN Bus Simulator")
    print(" Automotive ECU Simulation + Signal Validation")
    print(" Author: Shaik Masthan | shaikmasthan076@gmail.com")
    print("=" * 60)

    # ── Step 1: Simulate CAN bus ──────────────
    bus    = CANBus()
    frames = bus.run_simulation(duration_s=args.duration, verbose=args.verbose)

    # ── Step 2: Validate frames ───────────────
    validator = CANValidator(frames)
    results   = validator.run_all()

    # ── Step 3: Generate reports ──────────────
    json_path = os.path.join(args.output_dir, "can_validation_report.json")
    html_path = os.path.join(args.output_dir, "can_validation_report.html")

    export_json(results, json_path)
    export_html(results, len(frames), html_path)

    print(f"\n✅ Done! Open {html_path} in your browser to view the report.")


if __name__ == "__main__":
    main()
