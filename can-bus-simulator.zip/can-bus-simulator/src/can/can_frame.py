"""
can_frame.py
CAN frame encoder, decoder, and validator.
Mirrors what CANoe/CANalyzer does — pure Python, no hardware needed.
"""

import struct
import time
from dataclasses import dataclass, field
from typing import Optional


# ─────────────────────────────────────────────
# CAN Frame Types
# ─────────────────────────────────────────────
CAN_FRAME_STD = "standard"   # 11-bit ID
CAN_FRAME_EXT = "extended"   # 29-bit ID


@dataclass
class CANFrame:
    """Represents a single CAN bus frame."""
    arbitration_id: int
    data:           bytes
    timestamp:      float        = field(default_factory=time.time)
    frame_type:     str          = CAN_FRAME_STD
    is_remote:      bool         = False
    is_error:       bool         = False

    # ── Validation ───────────────────────────
    def __post_init__(self):
        if self.frame_type == CAN_FRAME_STD and not (0 <= self.arbitration_id <= 0x7FF):
            raise ValueError(f"Standard CAN ID must be 0–0x7FF, got 0x{self.arbitration_id:X}")
        if self.frame_type == CAN_FRAME_EXT and not (0 <= self.arbitration_id <= 0x1FFFFFFF):
            raise ValueError(f"Extended CAN ID must be 0–0x1FFFFFFF, got 0x{self.arbitration_id:X}")
        if len(self.data) > 8:
            raise ValueError(f"CAN data max 8 bytes, got {len(self.data)}")

    # ── Properties ───────────────────────────
    @property
    def dlc(self) -> int:
        """Data Length Code."""
        return len(self.data)

    @property
    def is_standard(self) -> bool:
        return self.frame_type == CAN_FRAME_STD

    # ── Encoding ─────────────────────────────
    def to_bytes(self) -> bytes:
        """
        Pack frame into raw bytes:
        [4B arbitration_id][1B flags][1B DLC][8B data padded]
        """
        flags = 0
        if self.frame_type == CAN_FRAME_EXT: flags |= 0x01
        if self.is_remote:                   flags |= 0x02
        if self.is_error:                    flags |= 0x04

        data_padded = self.data.ljust(8, b'\x00')
        return struct.pack(">IBBQ",
                           self.arbitration_id,
                           flags,
                           self.dlc,
                           int.from_bytes(data_padded, "big"))

    @classmethod
    def from_bytes(cls, raw: bytes) -> "CANFrame":
        """Unpack raw bytes into a CANFrame."""
        if len(raw) < 14:
            raise ValueError("Raw frame too short (need 14 bytes)")

        arb_id, flags, dlc, data_int = struct.unpack(">IBBQ", raw[:14])
        data_full = data_int.to_bytes(8, "big")
        data      = data_full[:dlc]

        frame_type = CAN_FRAME_EXT if (flags & 0x01) else CAN_FRAME_STD
        is_remote  = bool(flags & 0x02)
        is_error   = bool(flags & 0x04)

        return cls(arbitration_id=arb_id, data=data,
                   frame_type=frame_type, is_remote=is_remote, is_error=is_error)

    # ── Display ──────────────────────────────
    def __str__(self) -> str:
        id_fmt  = f"0x{self.arbitration_id:03X}" if self.is_standard else f"0x{self.arbitration_id:08X}"
        data_hex = " ".join(f"{b:02X}" for b in self.data)
        return (f"[{self.frame_type.upper()[:3]}] ID={id_fmt}  "
                f"DLC={self.dlc}  Data=[{data_hex}]  "
                f"t={self.timestamp:.3f}s")


# ─────────────────────────────────────────────
# CAN Signal — extract value from frame data
# ─────────────────────────────────────────────
@dataclass
class CANSignal:
    """Defines how to extract a signal from CAN data bytes."""
    name:        str
    start_bit:   int
    length:      int           # bits
    factor:      float = 1.0
    offset:      float = 0.0
    min_val:     float = 0.0
    max_val:     float = 0.0
    unit:        str   = ""
    is_signed:   bool  = False

    def decode(self, data: bytes) -> float:
        """Extract signal value from CAN frame data bytes."""
        raw = int.from_bytes(data.ljust(8, b'\x00'), "little")
        mask  = (1 << self.length) - 1
        value = (raw >> self.start_bit) & mask

        if self.is_signed and (value & (1 << (self.length - 1))):
            value -= (1 << self.length)

        return round(value * self.factor + self.offset, 4)

    def encode(self, physical_value: float) -> int:
        """Convert physical value back to raw integer for transmission."""
        raw = int((physical_value - self.offset) / self.factor)
        return raw & ((1 << self.length) - 1)
