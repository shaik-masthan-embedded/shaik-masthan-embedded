"""
can_bus.py
Simulates a CAN bus with multiple ECUs transmitting frames.
Mimics what you'd see on a real vehicle CAN network in CANoe.
"""

import time
import random
import threading
from collections import defaultdict
from typing import Callable, Dict, List, Optional
from can_frame import CANFrame, CANSignal, CAN_FRAME_STD


# ─────────────────────────────────────────────
# Automotive CAN Message Definitions
# (mirrors a real DBC file structure)
# ─────────────────────────────────────────────
AUTOMOTIVE_MESSAGES = {
    0x0C0: {
        "name": "EngineData",
        "sender": "ECM",
        "cycle_ms": 10,
        "signals": {
            "EngineRPM":    CANSignal("EngineRPM",    0,  16, factor=0.25, offset=0,   min_val=0,    max_val=16383.75, unit="rpm"),
            "EngineTemp":   CANSignal("EngineTemp",   16,  8, factor=1.0,  offset=-40, min_val=-40,  max_val=215,      unit="°C"),
            "ThrottlePos":  CANSignal("ThrottlePos",  24,  8, factor=0.4,  offset=0,   min_val=0,    max_val=100,      unit="%"),
        }
    },
    0x0D0: {
        "name": "VehicleSpeed",
        "sender": "ABS",
        "cycle_ms": 20,
        "signals": {
            "VehicleSpeed": CANSignal("VehicleSpeed",  0, 16, factor=0.01, offset=0, min_val=0, max_val=655.35, unit="km/h"),
            "WheelFL":      CANSignal("WheelFL",      16, 16, factor=0.01, offset=0, min_val=0, max_val=655.35, unit="km/h"),
            "WheelFR":      CANSignal("WheelFR",      32, 16, factor=0.01, offset=0, min_val=0, max_val=655.35, unit="km/h"),
        }
    },
    0x1A0: {
        "name": "TransmissionData",
        "sender": "TCM",
        "cycle_ms": 50,
        "signals": {
            "GearPosition": CANSignal("GearPosition",  0,  4, factor=1.0, offset=0, min_val=0, max_val=8,   unit=""),
            "GearRatio":    CANSignal("GearRatio",     4, 12, factor=0.1, offset=0, min_val=0, max_val=9.9, unit=""),
        }
    },
    0x2B0: {
        "name": "BrakeData",
        "sender": "ABS",
        "cycle_ms": 10,
        "signals": {
            "BrakePressure": CANSignal("BrakePressure", 0, 16, factor=0.1, offset=0, min_val=0, max_val=400, unit="bar"),
            "BrakeActive":   CANSignal("BrakeActive",  16,  1, factor=1.0, offset=0, min_val=0, max_val=1,   unit=""),
        }
    },
    0x3C0: {
        "name": "DiagnosticHeartbeat",
        "sender": "GW",
        "cycle_ms": 1000,
        "signals": {
            "LifeCounter":  CANSignal("LifeCounter",  0,  8, factor=1.0, offset=0, min_val=0, max_val=255, unit=""),
            "SystemStatus": CANSignal("SystemStatus", 8,  4, factor=1.0, offset=0, min_val=0, max_val=15,  unit=""),
        }
    },
}


# ─────────────────────────────────────────────
# ECU Simulator Node
# ─────────────────────────────────────────────
class ECUNode:
    """Simulates a single ECU transmitting CAN messages."""

    def __init__(self, name: str, msg_id: int, msg_def: dict, bus: "CANBus"):
        self.name    = name
        self.msg_id  = msg_id
        self.msg_def = msg_def
        self.bus     = bus
        self._life_counter = 0

    def generate_frame(self) -> CANFrame:
        """Generate a realistic CAN frame with simulated signal values."""
        data = bytearray(8)

        for sig_name, sig in self.msg_def["signals"].items():
            # Generate realistic values
            value = self._simulate_value(sig_name, sig)
            raw   = sig.encode(value)

            # Pack into data bytes (little-endian)
            current = int.from_bytes(data, "little")
            mask    = ((1 << sig.length) - 1) << sig.start_bit
            current = (current & ~mask) | ((raw << sig.start_bit) & mask)
            data    = bytearray(current.to_bytes(8, "little"))

        return CANFrame(arbitration_id=self.msg_id, data=bytes(data))

    def _simulate_value(self, name: str, sig: CANSignal) -> float:
        """Produce realistic simulated signal values."""
        sim_map = {
            "EngineRPM":     lambda: round(random.gauss(2500, 200), 2),
            "EngineTemp":    lambda: round(random.gauss(90, 2), 1),
            "ThrottlePos":   lambda: round(random.uniform(10, 40), 1),
            "VehicleSpeed":  lambda: round(random.gauss(80, 3), 2),
            "WheelFL":       lambda: round(random.gauss(80, 1), 2),
            "WheelFR":       lambda: round(random.gauss(80, 1), 2),
            "GearPosition":  lambda: random.choice([3, 4, 5]),
            "GearRatio":     lambda: round(random.uniform(1.0, 3.5), 1),
            "BrakePressure": lambda: round(random.uniform(0, 5), 1),
            "BrakeActive":   lambda: random.choice([0, 0, 0, 1]),
            "LifeCounter":   self._increment_counter,
            "SystemStatus":  lambda: 0x0,   # 0 = OK
        }
        fn = sim_map.get(name)
        if fn:
            val = fn()
            # Clamp to signal range
            val = max(sig.min_val, min(sig.max_val, val))
            return val
        return sig.min_val

    def _increment_counter(self) -> float:
        self._life_counter = (self._life_counter + 1) % 256
        return float(self._life_counter)


# ─────────────────────────────────────────────
# CAN Bus
# ─────────────────────────────────────────────
class CANBus:
    """
    Simulated CAN bus — multiple ECUs transmit frames,
    listeners can subscribe by message ID.
    """

    def __init__(self):
        self.frames:    List[CANFrame]                  = []
        self.listeners: Dict[int, List[Callable]]       = defaultdict(list)
        self._lock      = threading.Lock()
        self._running   = False

    def subscribe(self, msg_id: int, callback: Callable[[CANFrame], None]):
        """Subscribe to frames with a specific arbitration ID."""
        self.listeners[msg_id].append(callback)

    def transmit(self, frame: CANFrame):
        """Put a frame on the bus and notify all listeners."""
        with self._lock:
            self.frames.append(frame)
        for cb in self.listeners.get(frame.arbitration_id, []):
            cb(frame)

    def run_simulation(self, duration_s: float = 2.0, verbose: bool = False):
        """
        Simulate all ECUs transmitting for `duration_s` seconds.
        Each message respects its cycle time.
        """
        print(f"\n🚌 CAN Bus Simulation starting ({duration_s}s)...")
        nodes = [
            ECUNode(defn["sender"], msg_id, defn, self)
            for msg_id, defn in AUTOMOTIVE_MESSAGES.items()
        ]

        start = time.time()
        next_tx = {node.msg_id: start for node in nodes}

        while time.time() - start < duration_s:
            now = time.time()
            for node in nodes:
                cycle_s = AUTOMOTIVE_MESSAGES[node.msg_id]["cycle_ms"] / 1000.0
                if now >= next_tx[node.msg_id]:
                    frame = node.generate_frame()
                    self.transmit(frame)
                    next_tx[node.msg_id] = now + cycle_s
                    if verbose:
                        print(f"  TX  {frame}")
            time.sleep(0.001)  # 1ms resolution

        total = len(self.frames)
        print(f"✅ Simulation done — {total} frames captured")
        return self.frames
