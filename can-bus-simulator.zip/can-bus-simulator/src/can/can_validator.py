"""
can_validator.py
Validates CAN frames against rules — like a CAPL test node in CANoe.
Checks signal ranges, cycle times, life counters, and message presence.
"""

import time
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from can_frame import CANFrame, CANSignal
from can_bus   import AUTOMOTIVE_MESSAGES


# ─────────────────────────────────────────────
# Validation Result
# ─────────────────────────────────────────────
@dataclass
class ValidationResult:
    test_name:   str
    passed:      bool
    msg_id:      int
    signal_name: str
    value:       Optional[float]
    expected:    str
    actual:      str
    note:        str = ""


# ─────────────────────────────────────────────
# CAN Validator
# ─────────────────────────────────────────────
class CANValidator:
    """
    Validates captured CAN frames against a set of rules.
    Equivalent to CAPL test scripts in CANoe.
    """

    def __init__(self, frames: List[CANFrame]):
        self.frames  = frames
        self.results: List[ValidationResult] = []

        # Group frames by message ID
        self.by_id: Dict[int, List[CANFrame]] = {}
        for f in frames:
            self.by_id.setdefault(f.arbitration_id, []).append(f)

    # ── Run all checks ────────────────────────
    def run_all(self) -> List[ValidationResult]:
        print("\n" + "="*60)
        print(" CAN Bus Validation Suite")
        print("="*60)

        for msg_id, msg_def in AUTOMOTIVE_MESSAGES.items():
            print(f"\n[0x{msg_id:03X}] {msg_def['name']} ({msg_def['sender']})")
            self._check_message_present(msg_id, msg_def)
            self._check_signal_ranges(msg_id, msg_def)
            self._check_cycle_time(msg_id, msg_def)

        self._check_life_counter()
        self._print_summary()
        return self.results

    # ── Check 1: Message presence ─────────────
    def _check_message_present(self, msg_id: int, msg_def: dict):
        frames = self.by_id.get(msg_id, [])
        passed = len(frames) > 0
        result = ValidationResult(
            test_name   = "Message Present",
            passed      = passed,
            msg_id      = msg_id,
            signal_name = "-",
            value       = float(len(frames)),
            expected    = "> 0 frames",
            actual      = f"{len(frames)} frames",
        )
        self.results.append(result)
        self._print_result(result)

    # ── Check 2: Signal range validation ──────
    def _check_signal_ranges(self, msg_id: int, msg_def: dict):
        frames = self.by_id.get(msg_id, [])
        if not frames:
            return

        for sig_name, sig in msg_def["signals"].items():
            violations = 0
            total      = len(frames)

            for frame in frames:
                value = sig.decode(frame.data)
                if not (sig.min_val <= value <= sig.max_val):
                    violations += 1

            passed = violations == 0
            sample = sig.decode(frames[-1].data)

            result = ValidationResult(
                test_name   = "Signal Range",
                passed      = passed,
                msg_id      = msg_id,
                signal_name = sig_name,
                value       = sample,
                expected    = f"{sig.min_val} – {sig.max_val} {sig.unit}",
                actual      = f"{violations}/{total} violations",
                note        = f"Last sample: {sample} {sig.unit}",
            )
            self.results.append(result)
            self._print_result(result)

    # ── Check 3: Cycle time validation ────────
    def _check_cycle_time(self, msg_id: int, msg_def: dict):
        frames = self.by_id.get(msg_id, [])
        if len(frames) < 2:
            return

        expected_ms  = msg_def["cycle_ms"]
        tolerance_ms = expected_ms * 0.20  # ±20% tolerance

        intervals = [
            (frames[i].timestamp - frames[i-1].timestamp) * 1000
            for i in range(1, len(frames))
        ]
        avg_interval = sum(intervals) / len(intervals)
        violations   = sum(1 for iv in intervals
                           if abs(iv - expected_ms) > tolerance_ms)

        passed = violations == 0
        result = ValidationResult(
            test_name   = "Cycle Time",
            passed      = passed,
            msg_id      = msg_id,
            signal_name = "-",
            value       = round(avg_interval, 2),
            expected    = f"{expected_ms} ms ±{tolerance_ms:.0f} ms",
            actual      = f"avg {avg_interval:.1f} ms, {violations} violations",
        )
        self.results.append(result)
        self._print_result(result)

    # ── Check 4: Life counter continuity ──────
    def _check_life_counter(self):
        msg_id = 0x3C0
        frames = self.by_id.get(msg_id, [])
        if len(frames) < 2:
            return

        sig     = AUTOMOTIVE_MESSAGES[msg_id]["signals"]["LifeCounter"]
        jumps   = 0
        prev    = None

        for frame in frames:
            val = int(sig.decode(frame.data))
            if prev is not None:
                expected_next = (prev + 1) % 256
                if val != expected_next:
                    jumps += 1
            prev = val

        passed = jumps == 0
        result = ValidationResult(
            test_name   = "Life Counter",
            passed      = passed,
            msg_id      = msg_id,
            signal_name = "LifeCounter",
            value       = float(prev or 0),
            expected    = "Monotonically incrementing (mod 256)",
            actual      = f"{jumps} discontinuities in {len(frames)} frames",
        )
        self.results.append(result)
        print(f"\n[0x{msg_id:03X}] Life Counter Check")
        self._print_result(result)

    # ── Helpers ───────────────────────────────
    def _print_result(self, r: ValidationResult):
        icon = "  ✅ PASS" if r.passed else "  ❌ FAIL"
        sig  = f" [{r.signal_name}]" if r.signal_name != "-" else ""
        print(f"{icon}  {r.test_name}{sig}  →  {r.actual}")
        if not r.passed:
            print(f"           Expected: {r.expected}")
        if r.note:
            print(f"           Note: {r.note}")

    def _print_summary(self):
        passed = sum(1 for r in self.results if r.passed)
        total  = len(self.results)
        print("\n" + "="*60)
        print(f" Results: {passed}/{total} passed", end="")
        if passed == total:
            print("  🎉 All checks passed!")
        else:
            print(f"  ⚠️  {total - passed} check(s) failed")
        print("="*60)
