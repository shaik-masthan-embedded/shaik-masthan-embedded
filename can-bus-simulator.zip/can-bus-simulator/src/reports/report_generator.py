"""
report_generator.py
Generates JSON and HTML test reports from CAN validation results.
Similar to what CANoe Test Report generates — but open source.
"""

import json
from datetime import datetime
from typing import List
from can_validator import ValidationResult


# ─────────────────────────────────────────────
# JSON Report
# ─────────────────────────────────────────────
def export_json(results: List[ValidationResult], path: str):
    passed = sum(1 for r in results if r.passed)
    report = {
        "generated":  datetime.now().isoformat(),
        "tool":       "CAN Bus Simulator — Shaik Masthan",
        "summary": {
            "total":  len(results),
            "passed": passed,
            "failed": len(results) - passed,
            "pass_rate": f"{100 * passed / len(results):.1f}%"
        },
        "results": [
            {
                "test":    r.test_name,
                "msg_id":  f"0x{r.msg_id:03X}",
                "signal":  r.signal_name,
                "passed":  r.passed,
                "expected": r.expected,
                "actual":   r.actual,
                "note":     r.note,
            }
            for r in results
        ]
    }
    with open(path, "w") as f:
        json.dump(report, f, indent=2)
    print(f"\n📄 JSON report → {path}")


# ─────────────────────────────────────────────
# HTML Report
# ─────────────────────────────────────────────
def export_html(results: List[ValidationResult], frames_count: int, path: str):
    passed = sum(1 for r in results if r.passed)
    failed = len(results) - passed
    now    = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    rows = ""
    for r in results:
        status_cls  = "pass" if r.passed else "fail"
        status_text = "✅ PASS" if r.passed else "❌ FAIL"
        sig = r.signal_name if r.signal_name != "-" else ""
        rows += f"""
        <tr class="{status_cls}">
            <td>{r.test_name}</td>
            <td>0x{r.msg_id:03X}</td>
            <td>{sig}</td>
            <td class="status">{status_text}</td>
            <td>{r.expected}</td>
            <td>{r.actual}</td>
        </tr>"""

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>CAN Bus Validation Report</title>
<style>
  body       {{ font-family: 'Segoe UI', Arial, sans-serif; background:#0d1117; color:#c9d1d9; margin:0; padding:20px; }}
  h1         {{ color:#58a6ff; border-bottom:1px solid #30363d; padding-bottom:10px; }}
  .meta      {{ color:#8b949e; font-size:0.9em; margin-bottom:20px; }}
  .summary   {{ display:flex; gap:20px; margin-bottom:30px; }}
  .card      {{ background:#161b22; border:1px solid #30363d; border-radius:8px; padding:20px 30px; text-align:center; }}
  .card h2   {{ margin:0; font-size:2em; }}
  .card p    {{ margin:4px 0 0; color:#8b949e; font-size:0.85em; }}
  .green     {{ color:#3fb950; }}
  .red       {{ color:#f85149; }}
  .blue      {{ color:#58a6ff; }}
  table      {{ width:100%; border-collapse:collapse; background:#161b22; border-radius:8px; overflow:hidden; }}
  th         {{ background:#21262d; padding:12px 16px; text-align:left; color:#8b949e; font-size:0.85em; text-transform:uppercase; }}
  td         {{ padding:10px 16px; border-top:1px solid #21262d; font-size:0.9em; }}
  tr.pass td {{ }}
  tr.fail td {{ background:#1a0e0e; }}
  .status    {{ font-weight:bold; }}
  tr.pass .status {{ color:#3fb950; }}
  tr.fail .status {{ color:#f85149; }}
  footer     {{ margin-top:30px; color:#8b949e; font-size:0.8em; text-align:center; }}
</style>
</head>
<body>

<h1>🚌 CAN Bus Validation Report</h1>
<p class="meta">Generated: {now} &nbsp;|&nbsp; Tool: CAN Bus Simulator &nbsp;|&nbsp; Author: Shaik Masthan</p>

<div class="summary">
  <div class="card"><h2 class="blue">{frames_count}</h2><p>Frames Captured</p></div>
  <div class="card"><h2 class="blue">{len(results)}</h2><p>Tests Run</p></div>
  <div class="card"><h2 class="green">{passed}</h2><p>Passed</p></div>
  <div class="card"><h2 class="{"red" if failed else "green"}">{failed}</h2><p>Failed</p></div>
  <div class="card"><h2 class="{"green" if failed == 0 else "red"}">{100*passed//len(results)}%</h2><p>Pass Rate</p></div>
</div>

<table>
  <thead>
    <tr>
      <th>Test</th><th>Msg ID</th><th>Signal</th>
      <th>Status</th><th>Expected</th><th>Actual</th>
    </tr>
  </thead>
  <tbody>{rows}
  </tbody>
</table>

<footer>CAN Bus Simulator — Portfolio Project | Shaik Masthan | shaikmasthan076@gmail.com</footer>
</body>
</html>"""

    with open(path, "w") as f:
        f.write(html)
    print(f"📊 HTML report → {path}")
