# CAN Bus Simulator — Python Automotive ECU Simulation

![CI](https://github.com/shaik-masthan-embedded/can-bus-simulator/actions/workflows/ci.yml/badge.svg)
![Python](https://img.shields.io/badge/Python-3.8%2B-blue?logo=python)
![Protocol](https://img.shields.io/badge/Protocol-CAN%20ISO%2011898-orange)
![ECUs](https://img.shields.io/badge/ECUs-ECM%20%7C%20ABS%20%7C%20TCM%20%7C%20GW-green)

> **Portfolio project** — Pure Python CAN bus simulator with automotive ECU nodes, signal validation, and automated HTML/JSON reporting. Demonstrates CANoe/CAPL-equivalent testing skills without requiring hardware.

---

## 🎯 What This Project Demonstrates

| Skill | Implementation |
|---|---|
| **CAN Protocol** | Frame encoding/decoding, DLC, arbitration IDs (ISO 11898) |
| **Signal Decoding** | Factor/offset extraction, bit-level unpacking (mirrors DBC files) |
| **ECU Simulation** | 5 automotive ECUs: ECM, ABS, TCM, GW — each with realistic signals |
| **Test Automation** | CAPL-equivalent validation in Python — range, cycle time, life counter |
| **Report Generation** | HTML dashboard + JSON reports (like CANoe Test Report) |
| **CI/CD** | GitHub Actions pipeline — test → simulate → publish artifacts |

---

## 🚌 Simulated ECUs & Messages

| CAN ID | Message | ECU | Cycle | Signals |
|---|---|---|---|---|
| `0x0C0` | EngineData | ECM | 10ms | RPM, Temperature, Throttle |
| `0x0D0` | VehicleSpeed | ABS | 20ms | Speed, WheelFL, WheelFR |
| `0x1A0` | TransmissionData | TCM | 50ms | GearPosition, GearRatio |
| `0x2B0` | BrakeData | ABS | 10ms | BrakePressure, BrakeActive |
| `0x3C0` | DiagnosticHeartbeat | GW | 1000ms | LifeCounter, SystemStatus |

---

## ✅ Validation Checks

| Check | Description | CANoe Equivalent |
|---|---|---|
| **Message Present** | All expected messages received | CAPL: `on message` check |
| **Signal Range** | All signals within min/max limits | CAPL: `testCheckValueRange` |
| **Cycle Time** | Message periodicity within ±20% | CAPL: `testCheckCycleTime` |
| **Life Counter** | Monotonically incrementing (mod 256) | CAPL: sequence check |

---

## 📁 Project Structure

```
can-bus-simulator/
├── main.py                         # Entry point
├── src/
│   ├── can/
│   │   ├── can_frame.py            # CAN frame encoder/decoder + signal extraction
│   │   ├── can_bus.py              # Bus simulation + ECU nodes + message definitions
│   │   └── can_validator.py        # Validation rules engine
│   └── reports/
│       └── report_generator.py     # JSON + HTML report generator
├── tests/
│   └── test_can_frame.py           # Pytest unit tests
├── reports/                        # Generated reports (auto-created)
└── .github/workflows/ci.yml        # GitHub Actions pipeline
```

---

## 🚀 Quick Start

```bash
# Clone the repo
git clone https://github.com/shaik-masthan-embedded/can-bus-simulator.git
cd can-bus-simulator

# Run simulation (2 seconds, ~500 frames)
python main.py

# Run longer simulation
python main.py --duration 5

# See every frame as it's transmitted
python main.py --duration 2 --verbose

# Open the report
open reports/can_validation_report.html
```

---

## 📊 Sample Output

```
============================================================
 CAN Bus Simulator
 Automotive ECU Simulation + Signal Validation
============================================================

🚌 CAN Bus Simulation starting (2.0s)...
✅ Simulation done — 507 frames captured

[0x0C0] EngineData (ECM)
  ✅ PASS  Message Present  →  184 frames
  ✅ PASS  Signal Range [EngineRPM]   →  Last: 2422.75 rpm
  ✅ PASS  Signal Range [EngineTemp]  →  Last: 89.0 °C
  ✅ PASS  Cycle Time  →  avg 10.1 ms

[0x0D0] VehicleSpeed (ABS)
  ✅ PASS  Signal Range [VehicleSpeed] →  Last: 81.23 km/h

============================================================
 Results: 23/23 passed  🎉 All checks passed!
============================================================

📄 JSON report → reports/can_validation_report.json
📊 HTML report → reports/can_validation_report.html
```

---

## 👤 Author

**Shaik Masthan** — Senior Embedded Systems Engineer
5+ years automotive embedded | AUTOSAR | UDS | CAN | Python Automation
🔗 [LinkedIn](https://www.linkedin.com/in/shaik-masthan-senior-embedded-engineer)
📧 shaikmasthan076@gmail.com
