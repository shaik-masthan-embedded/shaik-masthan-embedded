/**
 * test_uds_services.c
 * Unit tests for UDS service handlers using Unity framework
 * Run with: make test
 */

#include "unity.h"
#include "uds_core.h"
#include "uds_services.h"
#include <string.h>

/* ----------------------------------------------------------------
 * Setup / Teardown
 * ---------------------------------------------------------------- */
void setUp(void)    { UDS_Init(); }
void tearDown(void) {}

/* ----------------------------------------------------------------
 * SID 0x10 — Diagnostic Session Control
 * ---------------------------------------------------------------- */
void test_DiagnosticSession_DefaultSession(void)
{
    uint8_t req[]      = { 0x10, 0x01 };
    UDS_Response_t resp;

    UDS_ProcessRequest(req, sizeof(req), &resp);

    TEST_ASSERT_EQUAL(0, resp.is_negative);
    TEST_ASSERT_EQUAL(0x50, resp.data[0]);  /* 0x10 + 0x40 */
    TEST_ASSERT_EQUAL(0x01, resp.data[1]);
    TEST_ASSERT_EQUAL(2,    resp.length);
}

void test_DiagnosticSession_ExtendedSession(void)
{
    uint8_t req[]      = { 0x10, 0x03 };
    UDS_Response_t resp;

    UDS_ProcessRequest(req, sizeof(req), &resp);

    TEST_ASSERT_EQUAL(0,    resp.is_negative);
    TEST_ASSERT_EQUAL(0x50, resp.data[0]);
    TEST_ASSERT_EQUAL(0x03, resp.data[1]);
}

void test_DiagnosticSession_InvalidSession(void)
{
    uint8_t req[]      = { 0x10, 0xFF };
    UDS_Response_t resp;

    UDS_ProcessRequest(req, sizeof(req), &resp);

    TEST_ASSERT_EQUAL(1,    resp.is_negative);
    TEST_ASSERT_EQUAL(0x7F, resp.data[0]);
    TEST_ASSERT_EQUAL(0x10, resp.data[1]);
    TEST_ASSERT_EQUAL(UDS_NRC_SUBFUNCTION_NOT_SUPPORTED, resp.data[2]);
}

/* ----------------------------------------------------------------
 * SID 0x11 — ECU Reset
 * ---------------------------------------------------------------- */
void test_EcuReset_HardReset(void)
{
    uint8_t req[]      = { 0x11, 0x01 };
    UDS_Response_t resp;

    UDS_ProcessRequest(req, sizeof(req), &resp);

    TEST_ASSERT_EQUAL(0,    resp.is_negative);
    TEST_ASSERT_EQUAL(0x51, resp.data[0]);
    TEST_ASSERT_EQUAL(0x01, resp.data[1]);
}

void test_EcuReset_InvalidType(void)
{
    uint8_t req[]      = { 0x11, 0x05 };
    UDS_Response_t resp;

    UDS_ProcessRequest(req, sizeof(req), &resp);

    TEST_ASSERT_EQUAL(1,    resp.is_negative);
    TEST_ASSERT_EQUAL(UDS_NRC_SUBFUNCTION_NOT_SUPPORTED, resp.data[2]);
}

/* ----------------------------------------------------------------
 * SID 0x22 — Read Data By Identifier
 * ---------------------------------------------------------------- */
void test_ReadDataById_SoftwareVersion(void)
{
    uint8_t req[]      = { 0x22, 0xF1, 0x89 };
    UDS_Response_t resp;

    UDS_ProcessRequest(req, sizeof(req), &resp);

    TEST_ASSERT_EQUAL(0,    resp.is_negative);
    TEST_ASSERT_EQUAL(0x62, resp.data[0]);  /* 0x22 + 0x40 */
    TEST_ASSERT_EQUAL(0xF1, resp.data[1]);
    TEST_ASSERT_EQUAL(0x89, resp.data[2]);
    TEST_ASSERT_EQUAL(6,    resp.length);
}

void test_ReadDataById_EngineTemp(void)
{
    uint8_t req[]      = { 0x22, 0x01, 0x00 };
    UDS_Response_t resp;

    UDS_ProcessRequest(req, sizeof(req), &resp);

    TEST_ASSERT_EQUAL(0,    resp.is_negative);
    TEST_ASSERT_EQUAL(0x55, resp.data[3]);  /* 85°C */
    TEST_ASSERT_EQUAL(4,    resp.length);
}

void test_ReadDataById_InvalidDID(void)
{
    uint8_t req[]      = { 0x22, 0xAB, 0xCD };
    UDS_Response_t resp;

    UDS_ProcessRequest(req, sizeof(req), &resp);

    TEST_ASSERT_EQUAL(1,    resp.is_negative);
    TEST_ASSERT_EQUAL(UDS_NRC_REQUEST_OUT_OF_RANGE, resp.data[2]);
}

/* ----------------------------------------------------------------
 * SID 0x27 — Security Access
 * ---------------------------------------------------------------- */
void test_SecurityAccess_RequestSeed(void)
{
    uint8_t req[]      = { 0x27, 0x01 };
    UDS_Response_t resp;

    UDS_ProcessRequest(req, sizeof(req), &resp);

    TEST_ASSERT_EQUAL(0,    resp.is_negative);
    TEST_ASSERT_EQUAL(0x67, resp.data[0]);
    TEST_ASSERT_EQUAL(0x01, resp.data[1]);
    TEST_ASSERT_EQUAL(6,    resp.length);
}

void test_SecurityAccess_ValidKey(void)
{
    UDS_Response_t resp;

    /* Step 1: Get seed */
    uint8_t seed_req[] = { 0x27, 0x01 };
    UDS_ProcessRequest(seed_req, sizeof(seed_req), &resp);
    TEST_ASSERT_EQUAL(0, resp.is_negative);

    /* Extract seed from response */
    uint32_t seed = (uint32_t)((resp.data[2] << 24) | (resp.data[3] << 16) |
                                (resp.data[4] <<  8) |  resp.data[5]);

    /* Step 2: Compute valid key */
    uint32_t key = seed ^ 0xDEAD1234;

    uint8_t key_req[] = {
        0x27, 0x02,
        (uint8_t)((key >> 24) & 0xFF),
        (uint8_t)((key >> 16) & 0xFF),
        (uint8_t)((key >>  8) & 0xFF),
        (uint8_t)( key        & 0xFF)
    };

    UDS_ProcessRequest(key_req, sizeof(key_req), &resp);

    TEST_ASSERT_EQUAL(0,    resp.is_negative);
    TEST_ASSERT_EQUAL(0x67, resp.data[0]);
    TEST_ASSERT_EQUAL(0x02, resp.data[1]);
}

void test_SecurityAccess_InvalidKey(void)
{
    UDS_Response_t resp;

    /* Get seed first */
    uint8_t seed_req[] = { 0x27, 0x01 };
    UDS_ProcessRequest(seed_req, sizeof(seed_req), &resp);

    /* Send wrong key */
    uint8_t bad_key[] = { 0x27, 0x02, 0xDE, 0xAD, 0xBE, 0xEF };
    UDS_ProcessRequest(bad_key, sizeof(bad_key), &resp);

    TEST_ASSERT_EQUAL(1,    resp.is_negative);
    TEST_ASSERT_EQUAL(UDS_NRC_SECURITY_ACCESS_DENIED, resp.data[2]);
}

/* ----------------------------------------------------------------
 * SID 0x2E — Write Data By Identifier
 * ---------------------------------------------------------------- */
void test_WriteDataById_WithoutSecurity(void)
{
    uint8_t req[]      = { 0x2E, 0x01, 0x00, 0x55 };
    UDS_Response_t resp;

    UDS_ProcessRequest(req, sizeof(req), &resp);

    TEST_ASSERT_EQUAL(1,    resp.is_negative);
    TEST_ASSERT_EQUAL(UDS_NRC_SECURITY_ACCESS_DENIED, resp.data[2]);
}

void test_WriteDataById_WithSecurity(void)
{
    UDS_Response_t resp;

    /* Unlock security first */
    uint8_t seed_req[] = { 0x27, 0x01 };
    UDS_ProcessRequest(seed_req, sizeof(seed_req), &resp);

    uint32_t seed = (uint32_t)((resp.data[2] << 24) | (resp.data[3] << 16) |
                                (resp.data[4] <<  8) |  resp.data[5]);
    uint32_t key  = seed ^ 0xDEAD1234;

    uint8_t key_req[] = {
        0x27, 0x02,
        (uint8_t)((key >> 24) & 0xFF),
        (uint8_t)((key >> 16) & 0xFF),
        (uint8_t)((key >>  8) & 0xFF),
        (uint8_t)( key        & 0xFF)
    };
    UDS_ProcessRequest(key_req, sizeof(key_req), &resp);
    TEST_ASSERT_EQUAL(0, resp.is_negative);

    /* Now write */
    uint8_t write_req[] = { 0x2E, 0x01, 0x00, 0x60 };
    UDS_ProcessRequest(write_req, sizeof(write_req), &resp);

    TEST_ASSERT_EQUAL(0,    resp.is_negative);
    TEST_ASSERT_EQUAL(0x6E, resp.data[0]);  /* 0x2E + 0x40 */
}

/* ----------------------------------------------------------------
 * Unknown SID
 * ---------------------------------------------------------------- */
void test_UnknownService(void)
{
    uint8_t req[]      = { 0xAA, 0x01 };
    UDS_Response_t resp;

    UDS_ProcessRequest(req, sizeof(req), &resp);

    TEST_ASSERT_EQUAL(1,    resp.is_negative);
    TEST_ASSERT_EQUAL(0x7F, resp.data[0]);
    TEST_ASSERT_EQUAL(0xAA, resp.data[1]);
    TEST_ASSERT_EQUAL(UDS_NRC_SERVICE_NOT_SUPPORTED, resp.data[2]);
}

/* ----------------------------------------------------------------
 * Main
 * ---------------------------------------------------------------- */
int main(void)
{
    UNITY_BEGIN();

    RUN_TEST(test_DiagnosticSession_DefaultSession);
    RUN_TEST(test_DiagnosticSession_ExtendedSession);
    RUN_TEST(test_DiagnosticSession_InvalidSession);

    RUN_TEST(test_EcuReset_HardReset);
    RUN_TEST(test_EcuReset_InvalidType);

    RUN_TEST(test_ReadDataById_SoftwareVersion);
    RUN_TEST(test_ReadDataById_EngineTemp);
    RUN_TEST(test_ReadDataById_InvalidDID);

    RUN_TEST(test_SecurityAccess_RequestSeed);
    RUN_TEST(test_SecurityAccess_ValidKey);
    RUN_TEST(test_SecurityAccess_InvalidKey);

    RUN_TEST(test_WriteDataById_WithoutSecurity);
    RUN_TEST(test_WriteDataById_WithSecurity);

    RUN_TEST(test_UnknownService);

    return UNITY_END();
}
