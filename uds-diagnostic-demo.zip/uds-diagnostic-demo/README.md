# UDS Diagnostic Demo — STM32 Firmware + CI/CD Pipeline

![CI Pipeline](https://github.com/YOUR_USERNAME/uds-diagnostic-demo/actions/workflows/ci.yml/badge.svg)
![Language](https://img.shields.io/badge/language-C%20%7C%20Python-blue)
![Standard](https://img.shields.io/badge/standard-ISO%2014229%20UDS-green)
![Platform](https://img.shields.io/badge/platform-STM32%20Cortex--M4-orange)

> **Portfolio project** demonstrating automotive-grade UDS diagnostics firmware (ISO 14229) running on STM32 Cortex-M4, with a full CI/CD pipeline for automated build, unit testing, and static analysis — no hardware required.

---

## 🎯 What This Project Demonstrates

| Skill | Implementation |
|---|---|
| **Embedded C** | UDS stack for STM32 Cortex-M4 (ARM GCC cross-compiled) |
| **ISO 14229 UDS** | SID 0x10, 0x11, 0x22, 0x27, 0x2E implemented |
| **Python Automation** | Full test automation suite with JSON reporting |
| **CI/CD** | GitHub Actions: build → test → static analysis |
| **Unit Testing** | Unity framework, 14 test cases, 100% service coverage |
| **Static Analysis** | cppcheck integrated in pipeline |

---

## 📁 Project Structure

```
uds-diagnostic-demo/
├── src/
│   └── uds/
│       ├── uds_core.h/c        # UDS session management & request routing
│       ├── uds_services.h/c    # Service handlers (SID 0x10/11/22/27/2E)
├── tests/
│   └── unit/
│       └── test_uds_services.c # 14 Unity unit tests
├── scripts/
│   └── uds_tester.py           # Python UDS automation with JSON reports
├── .github/
│   └── workflows/
│       └── ci.yml              # Full CI/CD pipeline
└── docs/
    └── uds_services.md         # Protocol documentation
```

---

## 🔧 UDS Services Implemented

| SID | Service | Sub-functions |
|---|---|---|
| `0x10` | Diagnostic Session Control | Default (01), Programming (02), Extended (03) |
| `0x11` | ECU Reset | Hard (01), KeyOffOn (02), Soft (03) |
| `0x22` | Read Data By Identifier | F189 (SW Ver), F18C (Serial), 0100 (Temp), 0101 (Speed) |
| `0x27` | Security Access | Seed (01) / Key (02) — XOR algorithm |
| `0x2E` | Write Data By Identifier | Requires security unlock |

---

## ⚙️ CI/CD Pipeline

```
Push/PR
   │
   ├── 1. Build       →  arm-none-eabi-gcc (Cortex-M4 cross-compile)
   ├── 2. Unit Tests  →  Unity framework (14 test cases)
   ├── 3. Automation  →  Python UDS tester + JSON report
   └── 4. Static      →  cppcheck (MISRA-compatible checks)
```

Every pull request gets automatic build verification and test results posted as a pipeline summary.

---

## 🚀 Running Locally

### Python Automation (no hardware, no compiler needed)
```bash
python scripts/uds_tester.py
# Report saved to: uds_test_report.json
```

### C Unit Tests (requires GCC + Unity)
```bash
# Clone Unity
git clone https://github.com/ThrowTheSwitch/Unity.git /tmp/Unity

# Build and run
gcc -I/tmp/Unity/src -Isrc/uds \
    /tmp/Unity/src/unity.c \
    src/uds/uds_core.c src/uds/uds_services.c \
    tests/unit/test_uds_services.c -o test_runner
./test_runner
```

### Cross-compile for STM32 (requires arm-none-eabi-gcc)
```bash
arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -O2 \
    -Isrc/uds src/uds/uds_core.c src/uds/uds_services.c \
    -c -o uds.o
```

---

## 📊 Sample Test Output

```
============================================================
 UDS Diagnostic Test Suite — Simulation Mode
============================================================

[SID 0x10] Diagnostic Session Control
  ✅ PASS  Default session
  ✅ PASS  Extended session
  ✅ PASS  Invalid session → NRC 0x12

[SID 0x22] Read Data By Identifier
  ✅ PASS  Read SW version (F189)
  ✅ PASS  Read engine temp (0100) → 85°C
  ✅ PASS  Read vehicle speed (0101) → 60 km/h

[SID 0x27] Security Access
  ✅ PASS  Request seed
  ✅ PASS  Send valid key → unlocked
  ✅ PASS  Wrong key → NRC 0x33

============================================================
 Results: 14/14 passed  🎉 All tests passed!
============================================================
```

---

## 👤 Author

**Shaik Masthan** — Senior Embedded Systems Engineer  
5+ years automotive embedded | AUTOSAR | UDS | CAN | Python Automation  
🔗 [LinkedIn](https://www.linkedin.com/in/shaik-masthan-senior-embedded-engineer)  
📧 shaikmasthan076@gmail.com
