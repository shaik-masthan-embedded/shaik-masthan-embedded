#include "uds_services.h"
#include "uds_core.h"
#include <string.h>

/* Forward declare internal session getter */
extern UDS_Session_t *UDS_GetSession(void);

/* ---------------------------------------------------------------
 * SID 0x10 — Diagnostic Session Control
 * --------------------------------------------------------------- */
void UDS_HandleDiagnosticSession(const uint8_t *req, uint16_t len, UDS_Response_t *resp)
{
    if (len < 2) {
        UDS_SendNegativeResponse(UDS_SID_DIAGNOSTIC_SESSION_CONTROL,
                                  UDS_NRC_CONDITIONS_NOT_CORRECT, resp);
        return;
    }

    uint8_t session_type = req[1];
    UDS_Session_t *sess  = UDS_GetSession();

    if (session_type == UDS_SESSION_DEFAULT    ||
        session_type == UDS_SESSION_PROGRAMMING ||
        session_type == UDS_SESSION_EXTENDED)
    {
        sess->current_session = session_type;
        sess->security_level  = 0; /* Reset security on session change */

        resp->data[0] = UDS_SID_DIAGNOSTIC_SESSION_CONTROL + UDS_POSITIVE_RESPONSE_OFFSET;
        resp->data[1] = session_type;
        resp->length  = 2;
    } else {
        UDS_SendNegativeResponse(UDS_SID_DIAGNOSTIC_SESSION_CONTROL,
                                  UDS_NRC_SUBFUNCTION_NOT_SUPPORTED, resp);
    }
}

/* ---------------------------------------------------------------
 * SID 0x11 — ECU Reset
 * --------------------------------------------------------------- */
void UDS_HandleEcuReset(const uint8_t *req, uint16_t len, UDS_Response_t *resp)
{
    if (len < 2) {
        UDS_SendNegativeResponse(UDS_SID_ECU_RESET,
                                  UDS_NRC_CONDITIONS_NOT_CORRECT, resp);
        return;
    }

    uint8_t reset_type = req[1];

    /* 0x01=HardReset, 0x02=KeyOffOnReset, 0x03=SoftReset */
    if (reset_type >= 0x01 && reset_type <= 0x03) {
        resp->data[0] = UDS_SID_ECU_RESET + UDS_POSITIVE_RESPONSE_OFFSET;
        resp->data[1] = reset_type;
        resp->length  = 2;
        /* In real firmware, trigger reset here */
    } else {
        UDS_SendNegativeResponse(UDS_SID_ECU_RESET,
                                  UDS_NRC_SUBFUNCTION_NOT_SUPPORTED, resp);
    }
}

/* ---------------------------------------------------------------
 * SID 0x22 — Read Data By Identifier
 * --------------------------------------------------------------- */
void UDS_HandleReadDataById(const uint8_t *req, uint16_t len, UDS_Response_t *resp)
{
    if (len < 3) {
        UDS_SendNegativeResponse(UDS_SID_READ_DATA_BY_ID,
                                  UDS_NRC_CONDITIONS_NOT_CORRECT, resp);
        return;
    }

    uint16_t did = (uint16_t)((req[1] << 8) | req[2]);

    resp->data[0] = UDS_SID_READ_DATA_BY_ID + UDS_POSITIVE_RESPONSE_OFFSET;
    resp->data[1] = req[1];
    resp->data[2] = req[2];

    switch (did) {
        case DID_ECU_SERIAL_NUMBER:
            /* 8-byte serial number */
            memcpy(&resp->data[3], "ECU12345", 8);
            resp->length = 11;
            break;

        case DID_SOFTWARE_VERSION:
            /* e.g. v1.2.3 */
            resp->data[3] = 0x01;
            resp->data[4] = 0x02;
            resp->data[5] = 0x03;
            resp->length  = 6;
            break;

        case DID_HARDWARE_VERSION:
            resp->data[3] = 0x01;
            resp->data[4] = 0x00;
            resp->length  = 5;
            break;

        case DID_ENGINE_TEMP:
            /* Engine temp in degrees C (e.g. 85°C = 0x55) */
            resp->data[3] = 0x55;
            resp->length  = 4;
            break;

        case DID_VEHICLE_SPEED:
            /* Speed in km/h (e.g. 60 km/h = 0x3C) */
            resp->data[3] = 0x3C;
            resp->length  = 4;
            break;

        default:
            UDS_SendNegativeResponse(UDS_SID_READ_DATA_BY_ID,
                                      UDS_NRC_REQUEST_OUT_OF_RANGE, resp);
            return;
    }
}

/* ---------------------------------------------------------------
 * SID 0x27 — Security Access
 * Seed/Key mechanism: key = seed XOR 0xDEAD
 * --------------------------------------------------------------- */
void UDS_HandleSecurityAccess(const uint8_t *req, uint16_t len, UDS_Response_t *resp)
{
    if (len < 2) {
        UDS_SendNegativeResponse(UDS_SID_SECURITY_ACCESS,
                                  UDS_NRC_CONDITIONS_NOT_CORRECT, resp);
        return;
    }

    UDS_Session_t *sess  = UDS_GetSession();
    uint8_t        sub   = req[1];

    if (sub == 0x01) {
        /* Request seed */
        sess->seed = 0xABCD1234; /* In real ECU: generate random seed */

        resp->data[0] = UDS_SID_SECURITY_ACCESS + UDS_POSITIVE_RESPONSE_OFFSET;
        resp->data[1] = 0x01;
        resp->data[2] = (sess->seed >> 24) & 0xFF;
        resp->data[3] = (sess->seed >> 16) & 0xFF;
        resp->data[4] = (sess->seed >>  8) & 0xFF;
        resp->data[5] = (sess->seed      ) & 0xFF;
        resp->length  = 6;

    } else if (sub == 0x02) {
        /* Send key */
        if (len < 6) {
            UDS_SendNegativeResponse(UDS_SID_SECURITY_ACCESS,
                                      UDS_NRC_CONDITIONS_NOT_CORRECT, resp);
            return;
        }

        uint32_t received_key = (uint32_t)((req[2] << 24) | (req[3] << 16) |
                                            (req[4] <<  8) |  req[5]);
        uint32_t expected_key = sess->seed ^ 0xDEAD1234;

        if (received_key == expected_key) {
            sess->security_level = 1;
            resp->data[0] = UDS_SID_SECURITY_ACCESS + UDS_POSITIVE_RESPONSE_OFFSET;
            resp->data[1] = 0x02;
            resp->length  = 2;
        } else {
            UDS_SendNegativeResponse(UDS_SID_SECURITY_ACCESS,
                                      UDS_NRC_SECURITY_ACCESS_DENIED, resp);
        }
    } else {
        UDS_SendNegativeResponse(UDS_SID_SECURITY_ACCESS,
                                  UDS_NRC_SUBFUNCTION_NOT_SUPPORTED, resp);
    }
}

/* ---------------------------------------------------------------
 * SID 0x2E — Write Data By Identifier
 * Requires security access (level >= 1)
 * --------------------------------------------------------------- */
void UDS_HandleWriteDataById(const uint8_t *req, uint16_t len, UDS_Response_t *resp)
{
    UDS_Session_t *sess = UDS_GetSession();

    if (sess->security_level < 1) {
        UDS_SendNegativeResponse(UDS_SID_WRITE_DATA_BY_ID,
                                  UDS_NRC_SECURITY_ACCESS_DENIED, resp);
        return;
    }

    if (len < 4) {
        UDS_SendNegativeResponse(UDS_SID_WRITE_DATA_BY_ID,
                                  UDS_NRC_CONDITIONS_NOT_CORRECT, resp);
        return;
    }

    uint16_t did = (uint16_t)((req[1] << 8) | req[2]);

    /* Only allow writing to writable DIDs */
    if (did == DID_ENGINE_TEMP || did == DID_VEHICLE_SPEED) {
        resp->data[0] = UDS_SID_WRITE_DATA_BY_ID + UDS_POSITIVE_RESPONSE_OFFSET;
        resp->data[1] = req[1];
        resp->data[2] = req[2];
        resp->length  = 3;
    } else {
        UDS_SendNegativeResponse(UDS_SID_WRITE_DATA_BY_ID,
                                  UDS_NRC_REQUEST_OUT_OF_RANGE, resp);
    }
}
