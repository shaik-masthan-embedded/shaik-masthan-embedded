#include "uds_core.h"
#include "uds_services.h"
#include <string.h>

/* Global session state */
static UDS_Session_t g_session;

/* Service handler table */
typedef void (*ServiceHandler_t)(const uint8_t*, uint16_t, UDS_Response_t*);

typedef struct {
    uint8_t           sid;
    ServiceHandler_t  handler;
} UDS_ServiceEntry_t;

static const UDS_ServiceEntry_t service_table[] = {
    { UDS_SID_DIAGNOSTIC_SESSION_CONTROL, UDS_HandleDiagnosticSession },
    { UDS_SID_ECU_RESET,                  UDS_HandleEcuReset           },
    { UDS_SID_READ_DATA_BY_ID,            UDS_HandleReadDataById       },
    { UDS_SID_SECURITY_ACCESS,            UDS_HandleSecurityAccess     },
    { UDS_SID_WRITE_DATA_BY_ID,           UDS_HandleWriteDataById      },
};

#define SERVICE_TABLE_SIZE (sizeof(service_table) / sizeof(service_table[0]))

/* ---------------------------------------------------------------
 * UDS_Init
 * Initialize UDS stack to default state
 * --------------------------------------------------------------- */
void UDS_Init(void)
{
    memset(&g_session, 0, sizeof(g_session));
    g_session.current_session = UDS_SESSION_DEFAULT;
    g_session.security_level  = 0;
}

/* ---------------------------------------------------------------
 * UDS_ProcessRequest
 * Route incoming request to the correct service handler
 * --------------------------------------------------------------- */
void UDS_ProcessRequest(const uint8_t *request, uint16_t length, UDS_Response_t *response)
{
    memset(response, 0, sizeof(UDS_Response_t));

    if (request == NULL || length == 0) {
        UDS_SendNegativeResponse(0x00, UDS_NRC_CONDITIONS_NOT_CORRECT, response);
        return;
    }

    uint8_t sid = request[0];

    for (size_t i = 0; i < SERVICE_TABLE_SIZE; i++) {
        if (service_table[i].sid == sid) {
            service_table[i].handler(request, length, response);
            return;
        }
    }

    /* No handler found */
    UDS_SendNegativeResponse(sid, UDS_NRC_SERVICE_NOT_SUPPORTED, response);
}

/* ---------------------------------------------------------------
 * UDS_SendNegativeResponse
 * Build a standard NRC response (0x7F, SID, NRC)
 * --------------------------------------------------------------- */
void UDS_SendNegativeResponse(uint8_t sid, uint8_t nrc, UDS_Response_t *response)
{
    response->data[0]  = 0x7F;
    response->data[1]  = sid;
    response->data[2]  = nrc;
    response->length   = 3;
    response->is_negative = 1;
}

/* ---------------------------------------------------------------
 * UDS_GetSession  (internal helper used by services)
 * --------------------------------------------------------------- */
UDS_Session_t *UDS_GetSession(void)
{
    return &g_session;
}
