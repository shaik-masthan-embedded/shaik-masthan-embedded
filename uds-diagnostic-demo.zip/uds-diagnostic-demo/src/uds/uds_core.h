#ifndef UDS_CORE_H
#define UDS_CORE_H

#include <stdint.h>
#include <stddef.h>

/* UDS Service IDs */
#define UDS_SID_DIAGNOSTIC_SESSION_CONTROL   0x10
#define UDS_SID_ECU_RESET                    0x11
#define UDS_SID_READ_DATA_BY_ID              0x22
#define UDS_SID_SECURITY_ACCESS              0x27
#define UDS_SID_WRITE_DATA_BY_ID             0x2E
#define UDS_SID_ROUTINE_CONTROL              0x31

/* UDS Session Types */
#define UDS_SESSION_DEFAULT                  0x01
#define UDS_SESSION_PROGRAMMING              0x02
#define UDS_SESSION_EXTENDED                 0x03

/* UDS Response Codes */
#define UDS_POSITIVE_RESPONSE_OFFSET         0x40
#define UDS_NRC_SERVICE_NOT_SUPPORTED        0x11
#define UDS_NRC_SUBFUNCTION_NOT_SUPPORTED    0x12
#define UDS_NRC_CONDITIONS_NOT_CORRECT       0x22
#define UDS_NRC_REQUEST_OUT_OF_RANGE         0x31
#define UDS_NRC_SECURITY_ACCESS_DENIED       0x33

/* Buffer sizes */
#define UDS_MAX_REQUEST_LEN                  256
#define UDS_MAX_RESPONSE_LEN                 256

/* UDS Response structure */
typedef struct {
    uint8_t  data[UDS_MAX_RESPONSE_LEN];
    uint16_t length;
    uint8_t  is_negative;
} UDS_Response_t;

/* UDS Session state */
typedef struct {
    uint8_t  current_session;
    uint8_t  security_level;
    uint32_t seed;
} UDS_Session_t;

/* Function prototypes */
void UDS_Init(void);
void UDS_ProcessRequest(const uint8_t *request, uint16_t length, UDS_Response_t *response);
void UDS_SendNegativeResponse(uint8_t sid, uint8_t nrc, UDS_Response_t *response);

#endif /* UDS_CORE_H */
