#ifndef UDS_SERVICES_H
#define UDS_SERVICES_H

#include "uds_core.h"

/* Service handlers — one per supported SID */
void UDS_HandleDiagnosticSession(const uint8_t *req, uint16_t len, UDS_Response_t *resp);
void UDS_HandleEcuReset         (const uint8_t *req, uint16_t len, UDS_Response_t *resp);
void UDS_HandleReadDataById     (const uint8_t *req, uint16_t len, UDS_Response_t *resp);
void UDS_HandleSecurityAccess   (const uint8_t *req, uint16_t len, UDS_Response_t *resp);
void UDS_HandleWriteDataById    (const uint8_t *req, uint16_t len, UDS_Response_t *resp);

/* Data Identifiers (DIDs) */
#define DID_ECU_SERIAL_NUMBER    0xF18C
#define DID_SOFTWARE_VERSION     0xF189
#define DID_HARDWARE_VERSION     0xF191
#define DID_ENGINE_TEMP          0x0100
#define DID_VEHICLE_SPEED        0x0101

#endif /* UDS_SERVICES_H */
