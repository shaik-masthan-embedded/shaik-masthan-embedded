"""
uds_tester.py
Python automation script to send UDS requests and validate responses.
Simulates what a CANoe/CANalyzer test would do — runs over a serial/socket interface.
For portfolio demo: runs in simulation mode (no hardware required).
"""

import struct
import argparse
import json
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional


# ─────────────────────────────────────────────
# UDS Constants
# ─────────────────────────────────────────────
SID_DIAGNOSTIC_SESSION  = 0x10
SID_ECU_RESET           = 0x11
SID_READ_DATA_BY_ID     = 0x22
SID_SECURITY_ACCESS     = 0x27
SID_WRITE_DATA_BY_ID    = 0x2E

NRC_SERVICE_NOT_SUPPORTED    = 0x11
NRC_SUBFUNCTION_NOT_SUPP     = 0x12
NRC_CONDITIONS_NOT_CORRECT   = 0x22
NRC_REQUEST_OUT_OF_RANGE     = 0x31
NRC_SECURITY_ACCESS_DENIED   = 0x33

DID_ECU_SERIAL   = 0xF18C
DID_SW_VERSION   = 0xF189
DID_HW_VERSION   = 0xF191
DID_ENGINE_TEMP  = 0x0100
DID_SPEED        = 0x0101


# ─────────────────────────────────────────────
# ECU Simulator (mirrors the C firmware logic)
# ─────────────────────────────────────────────
class ECUSimulator:
    SEED = 0xABCD1234
    KEY_XOR = 0xDEAD1234

    def __init__(self):
        self.session = 0x01
        self.security_level = 0
        self.seed = self.SEED

    def process(self, request: bytes) -> bytes:
        if not request:
            return bytes([0x7F, 0x00, NRC_CONDITIONS_NOT_CORRECT])

        sid = request[0]

        if sid == SID_DIAGNOSTIC_SESSION:
            return self._session_control(request)
        elif sid == SID_ECU_RESET:
            return self._ecu_reset(request)
        elif sid == SID_READ_DATA_BY_ID:
            return self._read_did(request)
        elif sid == SID_SECURITY_ACCESS:
            return self._security_access(request)
        elif sid == SID_WRITE_DATA_BY_ID:
            return self._write_did(request)
        else:
            return bytes([0x7F, sid, NRC_SERVICE_NOT_SUPPORTED])

    def _session_control(self, req):
        sub = req[1]
        if sub in (0x01, 0x02, 0x03):
            self.session = sub
            self.security_level = 0
            return bytes([0x50, sub])
        return bytes([0x7F, 0x10, NRC_SUBFUNCTION_NOT_SUPP])

    def _ecu_reset(self, req):
        sub = req[1]
        if 0x01 <= sub <= 0x03:
            return bytes([0x51, sub])
        return bytes([0x7F, 0x11, NRC_SUBFUNCTION_NOT_SUPP])

    def _read_did(self, req):
        did = (req[1] << 8) | req[2]
        base = bytes([0x62, req[1], req[2]])

        data_map = {
            DID_ECU_SERIAL:  b"ECU12345",
            DID_SW_VERSION:  bytes([0x01, 0x02, 0x03]),
            DID_HW_VERSION:  bytes([0x01, 0x00]),
            DID_ENGINE_TEMP: bytes([0x55]),
            DID_SPEED:       bytes([0x3C]),
        }

        if did in data_map:
            return base + data_map[did]
        return bytes([0x7F, 0x22, NRC_REQUEST_OUT_OF_RANGE])

    def _security_access(self, req):
        sub = req[1]
        if sub == 0x01:
            seed_bytes = struct.pack(">I", self.seed)
            return bytes([0x67, 0x01]) + seed_bytes
        elif sub == 0x02:
            key = struct.unpack(">I", req[2:6])[0]
            expected = self.seed ^ self.KEY_XOR
            if key == expected:
                self.security_level = 1
                return bytes([0x67, 0x02])
            return bytes([0x7F, 0x27, NRC_SECURITY_ACCESS_DENIED])
        return bytes([0x7F, 0x27, NRC_SUBFUNCTION_NOT_SUPP])

    def _write_did(self, req):
        if self.security_level < 1:
            return bytes([0x7F, 0x2E, NRC_SECURITY_ACCESS_DENIED])
        did = (req[1] << 8) | req[2]
        if did in (DID_ENGINE_TEMP, DID_SPEED):
            return bytes([0x6E, req[1], req[2]])
        return bytes([0x7F, 0x2E, NRC_REQUEST_OUT_OF_RANGE])


# ─────────────────────────────────────────────
# Test Result
# ─────────────────────────────────────────────
@dataclass
class TestResult:
    name: str
    passed: bool
    request: bytes
    response: bytes
    expected: bytes
    note: str = ""


# ─────────────────────────────────────────────
# UDS Test Suite
# ─────────────────────────────────────────────
class UDSTestSuite:
    def __init__(self, ecu: ECUSimulator):
        self.ecu = ecu
        self.results: List[TestResult] = []

    def run(self, req: bytes, expected: bytes, name: str, note: str = "") -> TestResult:
        resp = self.ecu.process(req)
        passed = resp[:len(expected)] == expected
        result = TestResult(name, passed, req, resp, expected, note)
        self.results.append(result)
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"  {status}  {name}")
        if not passed:
            print(f"         Expected: {expected.hex().upper()}")
            print(f"         Got:      {resp.hex().upper()}")
        return result

    def run_all(self):
        print("\n" + "="*60)
        print(" UDS Diagnostic Test Suite — Simulation Mode")
        print("="*60)

        # ── Session Control ──────────────────────────────────────
        print("\n[SID 0x10] Diagnostic Session Control")
        self.ecu.__init__()
        self.run(bytes([0x10, 0x01]), bytes([0x50, 0x01]), "Default session")
        self.run(bytes([0x10, 0x03]), bytes([0x50, 0x03]), "Extended session")
        self.run(bytes([0x10, 0xFF]), bytes([0x7F, 0x10, NRC_SUBFUNCTION_NOT_SUPP]),
                 "Invalid session → NRC 0x12")

        # ── ECU Reset ────────────────────────────────────────────
        print("\n[SID 0x11] ECU Reset")
        self.run(bytes([0x11, 0x01]), bytes([0x51, 0x01]), "Hard reset")
        self.run(bytes([0x11, 0x03]), bytes([0x51, 0x03]), "Soft reset")
        self.run(bytes([0x11, 0x09]), bytes([0x7F, 0x11, NRC_SUBFUNCTION_NOT_SUPP]),
                 "Invalid reset type → NRC 0x12")

        # ── Read Data By Identifier ──────────────────────────────
        print("\n[SID 0x22] Read Data By Identifier")
        self.run(bytes([0x22, 0xF1, 0x89]), bytes([0x62, 0xF1, 0x89, 0x01, 0x02, 0x03]),
                 "Read SW version (F189)")
        self.run(bytes([0x22, 0x01, 0x00]), bytes([0x62, 0x01, 0x00, 0x55]),
                 "Read engine temp (0100) → 85°C")
        self.run(bytes([0x22, 0x01, 0x01]), bytes([0x62, 0x01, 0x01, 0x3C]),
                 "Read vehicle speed (0101) → 60 km/h")
        self.run(bytes([0x22, 0xAB, 0xCD]), bytes([0x7F, 0x22, NRC_REQUEST_OUT_OF_RANGE]),
                 "Unknown DID → NRC 0x31")

        # ── Security Access ──────────────────────────────────────
        print("\n[SID 0x27] Security Access")
        self.ecu.__init__()
        resp_seed = self.ecu.process(bytes([0x27, 0x01]))
        seed = struct.unpack(">I", resp_seed[2:6])[0]
        key  = seed ^ ECUSimulator.KEY_XOR
        key_bytes = struct.pack(">I", key)

        self.run(bytes([0x27, 0x01]), bytes([0x67, 0x01]), "Request seed")
        self.run(bytes([0x27, 0x02]) + key_bytes, bytes([0x67, 0x02]),
                 "Send valid key → unlocked",
                 note=f"seed=0x{seed:08X} key=0x{key:08X}")
        self.run(bytes([0x27, 0x02, 0xDE, 0xAD, 0xBE, 0xEF]),
                 bytes([0x7F, 0x27, NRC_SECURITY_ACCESS_DENIED]),
                 "Wrong key → NRC 0x33")

        # ── Write Data By Identifier ─────────────────────────────
        print("\n[SID 0x2E] Write Data By Identifier")
        self.ecu.__init__()
        self.run(bytes([0x2E, 0x01, 0x00, 0x60]),
                 bytes([0x7F, 0x2E, NRC_SECURITY_ACCESS_DENIED]),
                 "Write without security → NRC 0x33")

        # Unlock then write
        self.ecu.process(bytes([0x27, 0x01]))
        key = self.ecu.seed ^ ECUSimulator.KEY_XOR
        self.ecu.process(bytes([0x27, 0x02]) + struct.pack(">I", key))
        self.run(bytes([0x2E, 0x01, 0x00, 0x60]), bytes([0x6E, 0x01, 0x00]),
                 "Write engine temp with security unlocked")

        # ── Summary ──────────────────────────────────────────────
        self._print_summary()
        return self.results

    def _print_summary(self):
        passed = sum(1 for r in self.results if r.passed)
        total  = len(self.results)
        print("\n" + "="*60)
        print(f" Results: {passed}/{total} passed", end="")
        if passed == total:
            print("  🎉 All tests passed!")
        else:
            print(f"  ⚠️  {total - passed} test(s) failed")
        print("="*60)

    def export_json(self, path: str):
        report = {
            "generated": datetime.now().isoformat(),
            "summary": {
                "total":  len(self.results),
                "passed": sum(1 for r in self.results if r.passed),
                "failed": sum(1 for r in self.results if not r.passed),
            },
            "tests": [
                {
                    "name":     r.name,
                    "passed":   r.passed,
                    "request":  r.request.hex().upper(),
                    "expected": r.expected.hex().upper(),
                    "response": r.response.hex().upper(),
                    "note":     r.note,
                }
                for r in self.results
            ]
        }
        with open(path, "w") as f:
            json.dump(report, f, indent=2)
        print(f"\n📄 Report saved → {path}")


# ─────────────────────────────────────────────
# Entry Point
# ─────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="UDS Diagnostic Test Automation")
    parser.add_argument("--report", default="uds_test_report.json",
                        help="Path for JSON test report (default: uds_test_report.json)")
    args = parser.parse_args()

    ecu   = ECUSimulator()
    suite = UDSTestSuite(ecu)
    suite.run_all()
    suite.export_json(args.report)
