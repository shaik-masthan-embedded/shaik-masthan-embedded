"""
arxml_validator.py
Validates AUTOSAR ARXML configuration files for MCAL compliance.
Checks mandatory elements, version consistency, and naming conventions.
Mirrors what EB Tresos does during configuration validation.
"""

import xml.etree.ElementTree as ET
import json
import sys
import os
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional


# ─────────────────────────────────────────────
# Validation Result
# ─────────────────────────────────────────────
@dataclass
class ARXMLCheckResult:
    check_name:  str
    passed:      bool
    file:        str
    element:     str
    expected:    str
    actual:      str
    note:        str = ""


# ─────────────────────────────────────────────
# ARXML Validator
# ─────────────────────────────────────────────
class ARXMLValidator:

    AUTOSAR_NS = "http://autosar.org/schema/r4.0"

    def __init__(self):
        self.results: List[ARXMLCheckResult] = []

    def validate_file(self, filepath: str) -> List[ARXMLCheckResult]:
        """Parse and validate a single ARXML file."""
        filename = os.path.basename(filepath)

        try:
            tree = ET.parse(filepath)
            root = tree.getroot()
        except ET.ParseError as e:
            self.results.append(ARXMLCheckResult(
                check_name="XML Parse",
                passed=False,
                file=filename,
                element="root",
                expected="Valid XML",
                actual=str(e)
            ))
            return self.results

        print(f"\n📄 Validating: {filename}")
        self._check_autosar_root(root, filename)
        self._check_admin_data(root, filename)
        self._check_module_configs(root, filename)
        self._check_naming_conventions(root, filename)
        self._check_version_consistency(root, filename)

        return self.results

    def validate_string(self, xml_string: str, name: str = "inline") -> List[ARXMLCheckResult]:
        """Validate ARXML from a string (for unit testing)."""
        try:
            root = ET.fromstring(xml_string)
        except ET.ParseError as e:
            self.results.append(ARXMLCheckResult(
                check_name="XML Parse",
                passed=False, file=name,
                element="root",
                expected="Valid XML", actual=str(e)
            ))
            return self.results

        self._check_autosar_root(root, name)
        self._check_naming_conventions(root, name)
        return self.results

    # ── Check: AUTOSAR root element ───────────
    def _check_autosar_root(self, root, filename):
        tag = root.tag.split("}")[-1] if "}" in root.tag else root.tag
        passed = tag == "AUTOSAR"
        self._add(ARXMLCheckResult(
            check_name = "Root Element",
            passed     = passed,
            file       = filename,
            element    = "root",
            expected   = "AUTOSAR",
            actual     = tag
        ))

    # ── Check: ADMIN-DATA present ────────────
    def _check_admin_data(self, root, filename):
        admin = root.find(".//{*}ADMIN-DATA")
        passed = admin is not None
        self._add(ARXMLCheckResult(
            check_name = "ADMIN-DATA Present",
            passed     = passed,
            file       = filename,
            element    = "ADMIN-DATA",
            expected   = "Present",
            actual     = "Present" if passed else "Missing"
        ))

    # ── Check: Module config elements ─────────
    def _check_module_configs(self, root, filename):
        containers = root.findall(".//{*}CONTAINERS")
        passed = len(containers) > 0
        self._add(ARXMLCheckResult(
            check_name = "CONTAINERS Present",
            passed     = passed,
            file       = filename,
            element    = "CONTAINERS",
            expected   = ">= 1 CONTAINERS element",
            actual     = f"{len(containers)} found"
        ))

        # Check SHORT-NAME in all packages
        packages = root.findall(".//{*}AR-PACKAGE")
        for pkg in packages:
            short_name = pkg.find("{*}SHORT-NAME")
            if short_name is None:
                short_name = pkg.find("SHORT-NAME")
            name_val = short_name.text if short_name is not None else None
            passed = name_val is not None and len(name_val) > 0
            self._add(ARXMLCheckResult(
                check_name = "Package SHORT-NAME",
                passed     = passed,
                file       = filename,
                element    = "AR-PACKAGE/SHORT-NAME",
                expected   = "Non-empty SHORT-NAME",
                actual     = name_val or "MISSING"
            ))

    # ── Check: Naming conventions ─────────────
    def _check_naming_conventions(self, root, filename):
        """Check SHORT-NAME elements follow AUTOSAR naming (UPPER_SNAKE_CASE)."""
        short_names = root.findall(".//{*}SHORT-NAME")
        if not short_names:
            short_names = root.findall(".//SHORT-NAME")

        violations = []
        for sn in short_names:
            if sn.text and not sn.text.replace("_", "").replace("-", "").isupper():
                if sn.text.islower():
                    violations.append(sn.text)

        passed = len(violations) == 0
        self._add(ARXMLCheckResult(
            check_name = "Naming Convention",
            passed     = passed,
            file       = filename,
            element    = "SHORT-NAME",
            expected   = "UPPER_SNAKE_CASE",
            actual     = f"{len(violations)} violations: {violations[:3]}" if violations else "OK",
        ))

    # ── Check: Version consistency ────────────
    def _check_version_consistency(self, root, filename):
        versions = root.findall(".//{*}CATEGORY")
        schema   = root.get("xsi:schemaLocation", "")
        passed   = True
        note     = "Schema location present" if schema else "No schema location"

        self._add(ARXMLCheckResult(
            check_name = "Schema Reference",
            passed     = passed,
            file       = filename,
            element    = "AUTOSAR/@schemaLocation",
            expected   = "xsi:schemaLocation defined",
            actual     = note
        ))

    # ── Helper ─────────────────────────────────
    def _add(self, result: ARXMLCheckResult):
        self.results.append(result)
        icon = "  ✅ PASS" if result.passed else "  ❌ FAIL"
        print(f"{icon}  {result.check_name}  →  {result.actual}")
        if not result.passed:
            print(f"           Expected: {result.expected}")

    # ── Summary ───────────────────────────────
    def print_summary(self):
        passed = sum(1 for r in self.results if r.passed)
        total  = len(self.results)
        print("\n" + "="*60)
        print(f" ARXML Validation: {passed}/{total} passed", end="")
        print("  🎉" if passed == total else f"  ⚠️  {total-passed} failed")
        print("="*60)

    def export_json(self, path: str):
        passed = sum(1 for r in self.results if r.passed)
        report = {
            "generated": datetime.now().isoformat(),
            "summary": {"total": len(self.results), "passed": passed,
                        "failed": len(self.results) - passed},
            "results": [
                {"check": r.check_name, "file": r.file, "element": r.element,
                 "passed": r.passed, "expected": r.expected, "actual": r.actual}
                for r in self.results
            ]
        }
        with open(path, "w") as f:
            json.dump(report, f, indent=2)
        print(f"\n📄 Report → {path}")


# ─────────────────────────────────────────────
# Entry Point
# ─────────────────────────────────────────────
if __name__ == "__main__":
    import glob

    print("=" * 60)
    print(" AUTOSAR ARXML Validator")
    print(" Author: Shaik Masthan | shaikmasthan076@gmail.com")
    print("=" * 60)

    validator = ARXMLValidator()
    arxml_files = glob.glob("config/**/*.arxml", recursive=True)

    if not arxml_files:
        print("\n⚠️  No .arxml files found in config/ — running with sample XML\n")
        # Run with built-in sample
        sample_xml = """<?xml version="1.0" encoding="UTF-8"?>
<AUTOSAR xmlns="http://autosar.org/schema/r4.0">
  <ADMIN-DATA>
    <LANGUAGE>EN</LANGUAGE>
  </ADMIN-DATA>
  <AR-PACKAGES>
    <AR-PACKAGE>
      <SHORT-NAME>MCAL_CONFIG</SHORT-NAME>
      <CONTAINERS>
        <ECUC-MODULE-CONFIGURATION-VALUES>
          <SHORT-NAME>SPI_CONFIG</SHORT-NAME>
        </ECUC-MODULE-CONFIGURATION-VALUES>
      </CONTAINERS>
    </AR-PACKAGE>
  </AR-PACKAGES>
</AUTOSAR>"""
        validator.validate_string(sample_xml, "sample_mcal.arxml")
    else:
        for f in arxml_files:
            validator.validate_file(f)

    validator.print_summary()
    os.makedirs("reports", exist_ok=True)
    validator.export_json("reports/arxml_validation_report.json")
