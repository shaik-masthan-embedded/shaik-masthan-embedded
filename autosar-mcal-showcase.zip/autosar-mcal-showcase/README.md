# AUTOSAR MCAL Config Showcase — SPI & CAN Drivers

![CI](https://github.com/shaik-masthan-embedded/autosar-mcal-showcase/actions/workflows/ci.yml/badge.svg)
![Language](https://img.shields.io/badge/language-Embedded%20C%20%7C%20Python-blue)
![Standard](https://img.shields.io/badge/AUTOSAR-ASW%204.4.0-orange)
![Target](https://img.shields.io/badge/target-NXP%20S32K148%20%7C%20STM32F4-green)

> **Portfolio project** — AUTOSAR-compliant MCAL driver implementations for SPI and CAN peripherals targeting NXP S32K148 / STM32F4, with Python ARXML validation and a full CI/CD pipeline.

---

## 🎯 What This Project Demonstrates

| Skill | Implementation |
|---|---|
| **AUTOSAR MCAL** | SPI & CAN drivers per ASW 4.4.0 specification |
| **ARXML Validation** | Python validator checking config compliance |
| **NXP S32K148** | FlexCAN, LPSPI register-level configuration |
| **STM32F4** | SPI1/SPI2, bxCAN peripheral awareness |
| **EB Tresos equivalent** | Manual config structures mirroring tool output |
| **CI/CD** | ARM cross-compile + ARXML validate + cppcheck |

---

## 📁 Project Structure

```
autosar-mcal-showcase/
├── src/
│   └── mcal/
│       ├── Std_Types.h             # AUTOSAR standard types
│       ├── spi/
│       │   ├── Spi.h               # SPI driver API (SWS_Spi_*)
│       │   └── Spi.c               # SPI driver implementation
│       └── can/
│           ├── Can.h               # CAN driver API (SWS_Can_*)
│           └── Can.c               # CAN driver implementation
├── config/
│   ├── spi/
│   │   └── Spi_Cfg.h               # SPI pre-compile config (EB Tresos equivalent)
│   └── can/
│       └── Can_Cfg.h               # CAN pre-compile config
├── scripts/
│   └── arxml_validator.py          # Python ARXML compliance checker
├── tests/
│   └── test_mcal_drivers.py        # Unit tests
└── .github/workflows/ci.yml        # CI/CD pipeline
```

---

## ⚙️ MCAL Drivers Implemented

### SPI Driver (AUTOSAR SWS_Spi)
| API | AUTOSAR Ref | Description |
|---|---|---|
| `Spi_Init()` | SWS_Spi_00184 | Initialise LPSPI peripheral |
| `Spi_WriteIB()` | SWS_Spi_00177 | Write to TX internal buffer |
| `Spi_ReadIB()` | SWS_Spi_00178 | Read from RX internal buffer |
| `Spi_SyncTransmit()` | SWS_Spi_00024 | Blocking sequence transmission |
| `Spi_AsyncTransmit()` | SWS_Spi_00020 | Non-blocking transmission |
| `Spi_GetStatus()` | SWS_Spi_00025 | Driver state query |

**Configured channels:** DAC (MCP4911), EEPROM (25LC256), Pressure Sensor, SPI LCD

### CAN Driver (AUTOSAR SWS_Can)
| API | AUTOSAR Ref | Description |
|---|---|---|
| `Can_Init()` | SWS_Can_00223 | Initialise FlexCAN peripheral |
| `Can_SetControllerMode()` | SWS_Can_00261 | STARTED / STOPPED / SLEEP |
| `Can_Write()` | SWS_Can_00233 | Transmit CAN PDU |
| `Can_GetControllerErrorState()` | SWS_Can_00454 | ACTIVE / PASSIVE / BUSOFF |
| `Can_MainFunction_Write/Read/BusOff()` | SWS_Can_* | OS-scheduled polling |

**Configured controllers:** FlexCAN0 (500kbps Powertrain), FlexCAN1 (250kbps Body)

---

## 🔍 ARXML Validator

Python tool that validates AUTOSAR ARXML configuration files — equivalent to EB Tresos validation:

```bash
python scripts/arxml_validator.py
```

**Checks performed:**
- ✅ Root element is `<AUTOSAR>`
- ✅ `ADMIN-DATA` block present
- ✅ All `AR-PACKAGE` have valid `SHORT-NAME`
- ✅ `CONTAINERS` element present
- ✅ Naming convention (UPPER_SNAKE_CASE)
- ✅ Schema reference present

---

## 🚀 Quick Start

```bash
# Clone
git clone https://github.com/shaik-masthan-embedded/autosar-mcal-showcase.git
cd autosar-mcal-showcase

# Run ARXML validator
python scripts/arxml_validator.py

# Cross-compile for ARM Cortex-M4 (requires arm-none-eabi-gcc)
arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -O2 \
    -Isrc/mcal -Iconfig/spi \
    -c src/mcal/spi/Spi.c -o Spi.o

# Run static analysis
cppcheck --enable=all --std=c99 -Isrc/mcal src/mcal/
```

---

## 📊 Sample ARXML Validation Output

```
============================================================
 AUTOSAR ARXML Validator
 Author: Shaik Masthan | shaikmasthan076@gmail.com
============================================================

📄 Validating: Spi_Cfg.arxml
  ✅ PASS  Root Element       →  AUTOSAR
  ✅ PASS  ADMIN-DATA Present →  Present
  ✅ PASS  CONTAINERS Present →  2 found
  ✅ PASS  Package SHORT-NAME →  SPI_DRIVER_CONFIG
  ✅ PASS  Naming Convention  →  OK

============================================================
 ARXML Validation: 5/5 passed  🎉
============================================================
```

---

## 👤 Author

**Shaik Masthan** — Senior Embedded Systems Engineer
5+ years automotive embedded | AUTOSAR | UDS | CAN | Python Automation
🔗 [LinkedIn](https://www.linkedin.com/in/shaik-masthan-senior-embedded-engineer)
📧 shaikmasthan076@gmail.com
