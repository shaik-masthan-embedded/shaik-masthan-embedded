"""
test_mcal_drivers.py
Python-level unit tests for MCAL driver logic verification.
Validates driver state machines, config handling, and API contracts.
"""

import subprocess
import sys
import os
import pytest


# ─────────────────────────────────────────────
# Compile helper — builds and runs C tests
# ─────────────────────────────────────────────
def compile_and_run(src_files: list, include_dirs: list, output: str) -> tuple:
    """Compile C files with gcc and return (returncode, stdout, stderr)."""
    includes = [f"-I{d}" for d in include_dirs]
    cmd = ["gcc", "-std=c99", "-Wall"] + includes + src_files + ["-o", output]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        return result.returncode, result.stdout, result.stderr

    run = subprocess.run([output], capture_output=True, text=True)
    return run.returncode, run.stdout, run.stderr


# ─────────────────────────────────────────────
# ARXML Validator Tests
# ─────────────────────────────────────────────
class TestARXMLValidator:

    def setup_method(self):
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../scripts"))
        from arxml_validator import ARXMLValidator
        self.ARXMLValidator = ARXMLValidator

    def _make_valid_xml(self, short_name="MY_MODULE"):
        return f"""<?xml version="1.0" encoding="UTF-8"?>
<AUTOSAR xmlns="http://autosar.org/schema/r4.0">
  <ADMIN-DATA><LANGUAGE>EN</LANGUAGE></ADMIN-DATA>
  <AR-PACKAGES>
    <AR-PACKAGE>
      <SHORT-NAME>{short_name}</SHORT-NAME>
      <CONTAINERS>
        <ECUC-MODULE-CONFIGURATION-VALUES>
          <SHORT-NAME>CFG</SHORT-NAME>
        </ECUC-MODULE-CONFIGURATION-VALUES>
      </CONTAINERS>
    </AR-PACKAGE>
  </AR-PACKAGES>
</AUTOSAR>"""

    def test_valid_arxml_passes_all_checks(self):
        v = self.ARXMLValidator()
        v.validate_string(self._make_valid_xml(), "test.arxml")
        failed = [r for r in v.results if not r.passed]
        assert len(failed) == 0, f"Unexpected failures: {[r.check_name for r in failed]}"

    def test_wrong_root_element_fails(self):
        xml = """<?xml version="1.0"?>
<WRONG_ROOT>
  <ADMIN-DATA/>
</WRONG_ROOT>"""
        v = self.ARXMLValidator()
        v.validate_string(xml, "bad_root.arxml")
        root_check = next(r for r in v.results if r.check_name == "Root Element")
        assert root_check.passed is False

    def test_missing_admin_data_fails(self):
        xml = """<?xml version="1.0"?>
<AUTOSAR xmlns="http://autosar.org/schema/r4.0">
  <AR-PACKAGES>
    <AR-PACKAGE><SHORT-NAME>PKG</SHORT-NAME>
      <CONTAINERS/>
    </AR-PACKAGE>
  </AR-PACKAGES>
</AUTOSAR>"""
        v = self.ARXMLValidator()
        v.validate_string(xml, "no_admin.arxml")
        check = next((r for r in v.results if r.check_name == "ADMIN-DATA Present"), None)
        if check:
            assert check.passed is False

    def test_valid_short_name_passes(self):
        v = self.ARXMLValidator()
        v.validate_string(self._make_valid_xml("SPI_DRIVER_CONFIG"), "test.arxml")
        check = next(r for r in v.results if r.check_name == "Naming Convention")
        assert check.passed is True

    def test_invalid_xml_returns_parse_error(self):
        v = self.ARXMLValidator()
        v.validate_string("<not valid xml <<", "broken.arxml")
        check = next(r for r in v.results if r.check_name == "XML Parse")
        assert check.passed is False

    def test_multiple_packages_all_checked(self):
        xml = """<?xml version="1.0"?>
<AUTOSAR xmlns="http://autosar.org/schema/r4.0">
  <ADMIN-DATA/>
  <AR-PACKAGES>
    <AR-PACKAGE><SHORT-NAME>SPI_CONFIG</SHORT-NAME><CONTAINERS/></AR-PACKAGE>
    <AR-PACKAGE><SHORT-NAME>CAN_CONFIG</SHORT-NAME><CONTAINERS/></AR-PACKAGE>
  </AR-PACKAGES>
</AUTOSAR>"""
        v = self.ARXMLValidator()
        v.validate_string(xml, "multi.arxml")
        name_checks = [r for r in v.results if r.check_name == "Package SHORT-NAME"]
        assert len(name_checks) == 2
        assert all(r.passed for r in name_checks)

    def test_json_export(self, tmp_path):
        v = self.ARXMLValidator()
        v.validate_string(self._make_valid_xml(), "test.arxml")
        out = str(tmp_path / "report.json")
        v.export_json(out)
        import json
        with open(out) as f:
            data = json.load(f)
        assert "summary" in data
        assert "results" in data
        assert data["summary"]["total"] == len(v.results)


# ─────────────────────────────────────────────
# Driver Config Tests (Python-level checks)
# ─────────────────────────────────────────────
class TestDriverConfig:
    """Verify config header constants are self-consistent."""

    def test_spi_channel_ids_unique(self):
        channels = [0, 1, 2, 3]  # SPI_CHANNEL_DAC..DISPLAY
        assert len(channels) == len(set(channels))

    def test_can_controller_ids_unique(self):
        controllers = [0, 1]  # CAN_CONTROLLER_0, CAN_CONTROLLER_1
        assert len(controllers) == len(set(controllers))

    def test_spi_max_channel_covers_all(self):
        SPI_MAX_CHANNEL = 4
        defined_channels = [0, 1, 2, 3]
        assert all(ch < SPI_MAX_CHANNEL for ch in defined_channels)

    def test_can_baudrates_valid(self):
        valid_baudrates = [125000, 250000, 500000, 1000000]
        configured = [500000, 250000]  # powertrain, body
        assert all(b in valid_baudrates for b in configured)

    def test_spi_sequences_within_max(self):
        SPI_MAX_SEQUENCE = 2
        sequences = [0, 1]  # SEQ_DAC_UPDATE, SEQ_EEPROM_RW
        assert all(s < SPI_MAX_SEQUENCE for s in sequences)


# ─────────────────────────────────────────────
# Run
# ─────────────────────────────────────────────
if __name__ == "__main__":
    pytest.main([__file__, "-v"])
