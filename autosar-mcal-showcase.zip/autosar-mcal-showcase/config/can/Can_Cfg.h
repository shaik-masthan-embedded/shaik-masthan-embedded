/**
 * @file    Can_Cfg.h
 * @brief   AUTOSAR CAN Driver — Pre-compile Configuration
 *          Target: NXP S32K148 — FlexCAN0, FlexCAN1
 */

#ifndef CAN_CFG_H
#define CAN_CFG_H

#include "Std_Types.h"

/*===========================================================================
 * General Switches
 *===========================================================================*/
#define CAN_DEV_ERROR_DETECT        STD_ON
#define CAN_VERSION_INFO_API        STD_ON
#define CAN_WAKEUP_SUPPORT          STD_OFF
#define CAN_BUSOFF_RECOVERY         STD_ON

#ifndef STD_ON
#define STD_ON  1U
#define STD_OFF 0U
#endif

/*===========================================================================
 * Controller IDs
 *===========================================================================*/
#define CAN_CONTROLLER_0    0U   /**< FlexCAN0 — Powertrain bus 500kbps */
#define CAN_CONTROLLER_1    1U   /**< FlexCAN1 — Body bus 250kbps */
#define CAN_MAX_CONTROLLERS 2U

/*===========================================================================
 * Hardware Transmit Handles (HTH)
 *===========================================================================*/
#define CAN_HTH_POWERTRAIN  0U
#define CAN_HTH_BODY        1U

/*===========================================================================
 * Hardware Receive Handles (HRH)
 *===========================================================================*/
#define CAN_HRH_POWERTRAIN  0U
#define CAN_HRH_BODY        1U

/*===========================================================================
 * Baud Rate
 *===========================================================================*/
#define CAN_BAUDRATE_500KBPS    500000UL
#define CAN_BAUDRATE_250KBPS    250000UL

/*===========================================================================
 * Mailbox count per controller
 *===========================================================================*/
#define CAN_MAX_MAILBOXES   16U

/*===========================================================================
 * Config Structures
 *===========================================================================*/
typedef struct {
    uint8   ControllerId;
    uint32  BaudRate;
    uint8   PropSeg;        /**< Propagation segment (TQ) */
    uint8   PhaseSeg1;      /**< Phase segment 1 (TQ) */
    uint8   PhaseSeg2;      /**< Phase segment 2 (TQ) */
    uint8   SJW;            /**< Sync jump width (TQ) */
    boolean BusOffRecovery;
    boolean LoopbackMode;   /**< For testing without physical bus */
} Can_ControllerConfigType;

typedef struct {
    const Can_ControllerConfigType *ControllerConfig;
    uint8                           NumControllers;
} Can_ConfigType;

/* Exported config instance */
extern const Can_ConfigType Can_Config;

#endif /* CAN_CFG_H */
