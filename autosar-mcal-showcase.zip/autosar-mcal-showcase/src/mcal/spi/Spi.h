/**
 * @file    Spi.h
 * @brief   AUTOSAR MCAL SPI Driver — ASW 4.4.0
 *
 * Implements AUTOSAR SPI Handler/Driver specification:
 * AUTOSAR_SWS_SPIHandlerDriver.pdf
 *
 * Target: NXP S32K148 / STM32F4 (configurable via Spi_Cfg.h)
 */

#ifndef SPI_H
#define SPI_H

#include "Std_Types.h"
#include "Spi_Cfg.h"

/*===========================================================================
 * AUTOSAR Version Info
 *===========================================================================*/
#define SPI_VENDOR_ID           0x0041U
#define SPI_MODULE_ID           0x0017U
#define SPI_AR_RELEASE_MAJOR    4U
#define SPI_AR_RELEASE_MINOR    4U
#define SPI_AR_RELEASE_PATCH    0U
#define SPI_SW_MAJOR_VERSION    1U
#define SPI_SW_MINOR_VERSION    0U
#define SPI_SW_PATCH_VERSION    0U

/*===========================================================================
 * Type Definitions (AUTOSAR SWS_Spi_00374)
 *===========================================================================*/

/** @brief SPI Channel ID type */
typedef uint8  Spi_ChannelType;

/** @brief SPI Job ID type */
typedef uint16 Spi_JobType;

/** @brief SPI Sequence ID type */
typedef uint8  Spi_SequenceType;

/** @brief SPI data buffer element type */
typedef uint8  Spi_DataBufferType;

/** @brief Number of data elements in a channel */
typedef uint16 Spi_NumberOfDataType;

/** @brief Hardware unit type */
typedef uint8  Spi_HWUnitType;

/**
 * @brief SPI async mode selection
 * SWS_Spi_00374
 */
typedef enum {
    SPI_POLLING_MODE    = 0x00U,  /**< Polling driven transmission */
    SPI_INTERRUPT_MODE  = 0x01U   /**< Interrupt driven transmission */
} Spi_AsyncModeType;

/**
 * @brief SPI status type
 * SWS_Spi_00373
 */
typedef enum {
    SPI_UNINIT      = 0x00U,  /**< Not initialised */
    SPI_IDLE        = 0x01U,  /**< No pending jobs */
    SPI_BUSY        = 0x02U   /**< Transmitting */
} Spi_StatusType;

/**
 * @brief SPI job/sequence result type
 * SWS_Spi_00372
 */
typedef enum {
    SPI_JOB_OK       = 0x00U,  /**< Last transmission successful */
    SPI_JOB_PENDING  = 0x01U,  /**< Transmission in progress */
    SPI_JOB_FAILED   = 0x02U,  /**< Last transmission failed */
    SPI_JOB_QUEUED   = 0x03U   /**< Job queued, not yet started */
} Spi_JobResultType;

typedef Spi_JobResultType Spi_SeqResultType;

/*===========================================================================
 * Function Declarations (AUTOSAR SWS_Spi)
 *===========================================================================*/

/**
 * @brief   Initialise SPI driver
 * @param   ConfigPtr  Pointer to post-build config (NULL for pre-compile)
 * SWS_Spi_00184
 */
void Spi_Init(const Spi_ConfigType *ConfigPtr);

/**
 * @brief   De-initialise SPI driver
 * @return  E_OK / E_NOT_OK
 * SWS_Spi_00021
 */
Std_ReturnType Spi_DeInit(void);

/**
 * @brief   Write data to a channel's TX buffer
 * SWS_Spi_00177
 */
Std_ReturnType Spi_WriteIB(Spi_ChannelType Channel,
                            const Spi_DataBufferType *DataBufferPtr);

/**
 * @brief   Read data from a channel's RX buffer
 * SWS_Spi_00178
 */
Std_ReturnType Spi_ReadIB(Spi_ChannelType Channel,
                           Spi_DataBufferType *DataBufferPtr);

/**
 * @brief   Transmit a sequence asynchronously
 * SWS_Spi_00020
 */
Std_ReturnType Spi_AsyncTransmit(Spi_SequenceType Sequence);

/**
 * @brief   Transmit a sequence synchronously (blocking)
 * SWS_Spi_00024
 */
Std_ReturnType Spi_SyncTransmit(Spi_SequenceType Sequence);

/**
 * @brief   Return current driver status
 * SWS_Spi_00025
 */
Spi_StatusType Spi_GetStatus(void);

/**
 * @brief   Return result of last job transmission
 * SWS_Spi_00026
 */
Spi_JobResultType Spi_GetJobResult(Spi_JobType Job);

/**
 * @brief   Return result of last sequence transmission
 * SWS_Spi_00027
 */
Spi_SeqResultType Spi_GetSequenceResult(Spi_SequenceType Sequence);

/**
 * @brief   Set async transmission mode (polling/interrupt)
 * SWS_Spi_00150
 */
Std_ReturnType Spi_SetAsyncMode(Spi_AsyncModeType Mode);

/**
 * @brief   SPI main function — call from OS task (polling mode)
 * SWS_Spi_00153
 */
void Spi_MainFunction_Handling(void);

#endif /* SPI_H */
