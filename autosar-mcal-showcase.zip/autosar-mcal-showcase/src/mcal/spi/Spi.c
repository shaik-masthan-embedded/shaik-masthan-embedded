/**
 * @file    Spi.c
 * @brief   AUTOSAR MCAL SPI Driver Implementation — ASW 4.4.0
 *          Target: NXP S32K148 (LPSPI peripheral)
 */

#include "Spi.h"
#include <string.h>

/*===========================================================================
 * Internal State
 *===========================================================================*/
static Spi_StatusType      Spi_DriverStatus                        = SPI_UNINIT;
static Spi_JobResultType   Spi_JobResult[SPI_MAX_JOB];
static Spi_SeqResultType   Spi_SeqResult[SPI_MAX_SEQUENCE];

/* Internal buffers */
static Spi_DataBufferType  Spi_TxBuf[SPI_MAX_CHANNEL][256];
static Spi_DataBufferType  Spi_RxBuf[SPI_MAX_CHANNEL][256];
static Spi_NumberOfDataType Spi_TxLen[SPI_MAX_CHANNEL];

static const Spi_ConfigType *Spi_CfgPtr = NULL_PTR;

/*===========================================================================
 * Spi_Init
 *===========================================================================*/
void Spi_Init(const Spi_ConfigType *ConfigPtr)
{
    uint8 i;

    /* SWS_Spi_00013: DET check */
    if (Spi_DriverStatus != SPI_UNINIT) {
        return; /* Already initialised — report DET in production */
    }

    Spi_CfgPtr = ConfigPtr;

    /* Initialise result arrays */
    for (i = 0U; i < SPI_MAX_JOB; i++) {
        Spi_JobResult[i] = SPI_JOB_OK;
    }
    for (i = 0U; i < SPI_MAX_SEQUENCE; i++) {
        Spi_SeqResult[i] = SPI_JOB_OK;
    }

    /* Clear buffers */
    memset(Spi_TxBuf, 0, sizeof(Spi_TxBuf));
    memset(Spi_RxBuf, 0, sizeof(Spi_RxBuf));
    memset(Spi_TxLen, 0, sizeof(Spi_TxLen));

    /*
     * Hardware init would go here for real target:
     *   LPSPI0->CR  = LPSPI_CR_MEN_MASK;
     *   LPSPI0->TCR = LPSPI_TCR_CPOL(cpol) | LPSPI_TCR_CPHA(cpha) | ...
     * Abstracted for portable simulation.
     */

    Spi_DriverStatus = SPI_IDLE;
}

/*===========================================================================
 * Spi_DeInit
 *===========================================================================*/
Std_ReturnType Spi_DeInit(void)
{
    if (Spi_DriverStatus == SPI_UNINIT) {
        return E_NOT_OK;
    }
    if (Spi_DriverStatus == SPI_BUSY) {
        return E_NOT_OK; /* SWS_Spi_00021: cannot deinit while busy */
    }

    Spi_DriverStatus = SPI_UNINIT;
    Spi_CfgPtr       = NULL_PTR;
    return E_OK;
}

/*===========================================================================
 * Spi_WriteIB — Write to internal TX buffer
 *===========================================================================*/
Std_ReturnType Spi_WriteIB(Spi_ChannelType Channel,
                            const Spi_DataBufferType *DataBufferPtr)
{
    if (Spi_DriverStatus == SPI_UNINIT) return E_NOT_OK;
    if (Channel >= SPI_MAX_CHANNEL)     return E_NOT_OK;
    if (DataBufferPtr == NULL_PTR)      return E_NOT_OK;

    /* Copy single element into TX buffer (simplified) */
    Spi_TxBuf[Channel][0] = *DataBufferPtr;
    Spi_TxLen[Channel]    = 1U;

    return E_OK;
}

/*===========================================================================
 * Spi_ReadIB — Read from internal RX buffer
 *===========================================================================*/
Std_ReturnType Spi_ReadIB(Spi_ChannelType Channel,
                           Spi_DataBufferType *DataBufferPtr)
{
    if (Spi_DriverStatus == SPI_UNINIT) return E_NOT_OK;
    if (Channel >= SPI_MAX_CHANNEL)     return E_NOT_OK;
    if (DataBufferPtr == NULL_PTR)      return E_NOT_OK;

    *DataBufferPtr = Spi_RxBuf[Channel][0];
    return E_OK;
}

/*===========================================================================
 * Spi_SyncTransmit — Blocking transmission
 *===========================================================================*/
Std_ReturnType Spi_SyncTransmit(Spi_SequenceType Sequence)
{
    if (Spi_DriverStatus == SPI_UNINIT) return E_NOT_OK;
    if (Sequence >= SPI_MAX_SEQUENCE)   return E_NOT_OK;
    if (Spi_DriverStatus == SPI_BUSY)   return E_NOT_OK;

    Spi_DriverStatus       = SPI_BUSY;
    Spi_SeqResult[Sequence] = SPI_JOB_PENDING;

    /*
     * Real HW transmission:
     *   while (!(LPSPI0->SR & LPSPI_SR_TDF_MASK));
     *   LPSPI0->TDR = txData;
     *   while (!(LPSPI0->SR & LPSPI_SR_RDF_MASK));
     *   rxData = LPSPI0->RDR;
     * Simulated here — just echo TX to RX for demo.
     */
    uint8 ch;
    for (ch = 0U; ch < SPI_MAX_CHANNEL; ch++) {
        if (Spi_TxLen[ch] > 0U) {
            /* Simulate loopback: RX = TX (for unit testing) */
            Spi_RxBuf[ch][0] = Spi_TxBuf[ch][0];
        }
    }

    Spi_SeqResult[Sequence] = SPI_JOB_OK;
    Spi_DriverStatus        = SPI_IDLE;
    return E_OK;
}

/*===========================================================================
 * Spi_AsyncTransmit
 *===========================================================================*/
Std_ReturnType Spi_AsyncTransmit(Spi_SequenceType Sequence)
{
    if (Spi_DriverStatus == SPI_UNINIT) return E_NOT_OK;
    if (Sequence >= SPI_MAX_SEQUENCE)   return E_NOT_OK;

    Spi_SeqResult[Sequence] = SPI_JOB_QUEUED;
    Spi_DriverStatus        = SPI_BUSY;

    /* In real implementation: start DMA/interrupt-driven transfer */
    /* For simulation: immediately complete */
    Spi_SeqResult[Sequence] = SPI_JOB_OK;
    Spi_DriverStatus        = SPI_IDLE;

    return E_OK;
}

/*===========================================================================
 * Getters
 *===========================================================================*/
Spi_StatusType Spi_GetStatus(void)
{
    return Spi_DriverStatus;
}

Spi_JobResultType Spi_GetJobResult(Spi_JobType Job)
{
    if (Job >= SPI_MAX_JOB) return SPI_JOB_FAILED;
    return Spi_JobResult[Job];
}

Spi_SeqResultType Spi_GetSequenceResult(Spi_SequenceType Sequence)
{
    if (Sequence >= SPI_MAX_SEQUENCE) return SPI_JOB_FAILED;
    return Spi_SeqResult[Sequence];
}

Std_ReturnType Spi_SetAsyncMode(Spi_AsyncModeType Mode)
{
    if (Spi_DriverStatus == SPI_UNINIT) return E_NOT_OK;
    (void)Mode; /* Store in config in full implementation */
    return E_OK;
}

void Spi_MainFunction_Handling(void)
{
    /* Called from OS task in polling mode — process pending jobs */
    /* Implemented as stub for simulation */
}
