/**
 * @file    Std_Types.h
 * @brief   AUTOSAR Standard Types — ASW 4.4.0
 *          AUTOSAR_SWS_StandardTypes.pdf
 */

#ifndef STD_TYPES_H
#define STD_TYPES_H

#include <stdint.h>
#include <stddef.h>

/*===========================================================================
 * Primitive Types
 *===========================================================================*/
typedef uint8_t   uint8;
typedef uint16_t  uint16;
typedef uint32_t  uint32;
typedef uint64_t  uint64;
typedef int8_t    sint8;
typedef int16_t   sint16;
typedef int32_t   sint32;
typedef float     float32;
typedef double    float64;
typedef uint8     boolean;

/*===========================================================================
 * Standard Return Type
 *===========================================================================*/
typedef uint8 Std_ReturnType;

#define E_OK        ((Std_ReturnType)0x00U)
#define E_NOT_OK    ((Std_ReturnType)0x01U)

/*===========================================================================
 * Boolean
 *===========================================================================*/
#ifndef TRUE
#define TRUE    ((boolean)1U)
#endif
#ifndef FALSE
#define FALSE   ((boolean)0U)
#endif

/*===========================================================================
 * NULL pointer
 *===========================================================================*/
#ifndef NULL_PTR
#define NULL_PTR    ((void*)0)
#endif

/*===========================================================================
 * Std_VersionInfoType
 *===========================================================================*/
typedef struct {
    uint16 vendorID;
    uint16 moduleID;
    uint8  sw_major_version;
    uint8  sw_minor_version;
    uint8  sw_patch_version;
} Std_VersionInfoType;

#endif /* STD_TYPES_H */
