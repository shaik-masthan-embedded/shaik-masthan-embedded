/**
 * @file    Can.h
 * @brief   AUTOSAR MCAL CAN Driver — ASW 4.4.0
 *          AUTOSAR_SWS_CANDriver.pdf
 *
 * Target: NXP S32K148 (FlexCAN peripheral)
 */

#ifndef CAN_H
#define CAN_H

#include "Std_Types.h"
#include "Can_Cfg.h"

/*===========================================================================
 * AUTOSAR Version Info
 *===========================================================================*/
#define CAN_VENDOR_ID           0x0041U
#define CAN_MODULE_ID           0x0050U
#define CAN_AR_RELEASE_MAJOR    4U
#define CAN_AR_RELEASE_MINOR    4U

/*===========================================================================
 * Type Definitions
 *===========================================================================*/

/** @brief CAN Controller ID */
typedef uint8 Can_HwHandleType;

/** @brief CAN ID — standard (11-bit) or extended (29-bit) */
typedef uint32 Can_IdType;

/**
 * @brief CAN Controller state
 * SWS_Can_00404
 */
typedef enum {
    CAN_CS_UNINIT   = 0x00U,
    CAN_CS_STARTED  = 0x01U,
    CAN_CS_STOPPED  = 0x02U,
    CAN_CS_SLEEP    = 0x03U
} Can_ControllerStateType;

/**
 * @brief CAN error state
 * SWS_Can_00405
 */
typedef enum {
    CAN_ERRORSTATE_ACTIVE   = 0x00U,
    CAN_ERRORSTATE_PASSIVE  = 0x01U,
    CAN_ERRORSTATE_BUSOFF   = 0x02U
} Can_ErrorStateType;

/**
 * @brief CAN PDU (Protocol Data Unit)
 * SWS_Can_00415
 */
typedef struct {
    Can_IdType  id;
    uint8       length;
    uint8      *sdu;    /**< Pointer to data payload */
} Can_PduType;

/**
 * @brief Return type for Can_Write
 */
typedef enum {
    CAN_OK      = 0x00U,
    CAN_NOT_OK  = 0x01U,
    CAN_BUSY    = 0x02U
} Can_ReturnType;

/*===========================================================================
 * Function Declarations
 *===========================================================================*/

/** @brief Initialise CAN driver — SWS_Can_00223 */
void Can_Init(const Can_ConfigType *Config);

/** @brief De-initialise — SWS_Can_00363 */
void Can_DeInit(void);

/** @brief Set controller mode (STARTED/STOPPED/SLEEP) — SWS_Can_00261 */
Std_ReturnType Can_SetControllerMode(uint8 Controller,
                                      Can_ControllerStateType Transition);

/** @brief Transmit a CAN frame — SWS_Can_00233 */
Can_ReturnType Can_Write(Can_HwHandleType Hth, const Can_PduType *PduInfo);

/** @brief Get controller error state — SWS_Can_00454 */
Std_ReturnType Can_GetControllerErrorState(uint8 ControllerId,
                                            Can_ErrorStateType *ErrorStatePtr);

/** @brief Get controller Rx/Tx error counters */
Std_ReturnType Can_GetControllerRxErrorCounter(uint8 ControllerId,
                                                uint8 *RxErrorCounterPtr);
Std_ReturnType Can_GetControllerTxErrorCounter(uint8 ControllerId,
                                                uint8 *TxErrorCounterPtr);

/** @brief Main function — called from OS for polling mode */
void Can_MainFunction_Write(void);
void Can_MainFunction_Read(void);
void Can_MainFunction_BusOff(void);

#endif /* CAN_H */
