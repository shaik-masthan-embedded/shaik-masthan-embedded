/**
 * @file    Can.c
 * @brief   AUTOSAR MCAL CAN Driver Implementation
 *          Target: NXP S32K148 — FlexCAN peripheral
 */

#include "Can.h"
#include <string.h>

/*===========================================================================
 * Internal State
 *===========================================================================*/
typedef struct {
    Can_ControllerStateType state;
    Can_ErrorStateType      error_state;
    uint8                   rx_error_cnt;
    uint8                   tx_error_cnt;
    uint8                   tx_buf[CAN_MAX_MAILBOXES][8];
    uint8                   tx_len[CAN_MAX_MAILBOXES];
    uint32                  tx_id [CAN_MAX_MAILBOXES];
    uint8                   tx_pending;
} Can_ControllerType;

static Can_ControllerType      Can_Controllers[CAN_MAX_CONTROLLERS];
static const Can_ConfigType   *Can_CfgPtr = NULL_PTR;
static boolean                 Can_Initialized = FALSE;

/*===========================================================================
 * Can_Init
 *===========================================================================*/
void Can_Init(const Can_ConfigType *Config)
{
    uint8 i;

    if (Can_Initialized == TRUE) return;

    Can_CfgPtr = Config;

    for (i = 0U; i < CAN_MAX_CONTROLLERS; i++) {
        Can_Controllers[i].state         = CAN_CS_STOPPED;
        Can_Controllers[i].error_state   = CAN_ERRORSTATE_ACTIVE;
        Can_Controllers[i].rx_error_cnt  = 0U;
        Can_Controllers[i].tx_error_cnt  = 0U;
        Can_Controllers[i].tx_pending    = 0U;
        memset(Can_Controllers[i].tx_buf, 0, sizeof(Can_Controllers[i].tx_buf));
        memset(Can_Controllers[i].tx_len, 0, sizeof(Can_Controllers[i].tx_len));
        memset(Can_Controllers[i].tx_id,  0, sizeof(Can_Controllers[i].tx_id));
    }

    /*
     * Real hardware initialisation for NXP S32K148 FlexCAN:
     *
     * FlexCAN0->MCR  |= CAN_MCR_SOFTRST_MASK;
     * while (FlexCAN0->MCR & CAN_MCR_SOFTRST_MASK);
     * FlexCAN0->CTRL1 = CAN_CTRL1_PRESDIV(presdiv) |
     *                   CAN_CTRL1_RJW(sjw)          |
     *                   CAN_CTRL1_PSEG1(pseg1)       |
     *                   CAN_CTRL1_PSEG2(pseg2)       |
     *                   CAN_CTRL1_PROPSEG(propseg);
     * FlexCAN0->MCR  &= ~CAN_MCR_HALT_MASK;
     *
     * Abstracted for portable simulation.
     */

    Can_Initialized = TRUE;
}

/*===========================================================================
 * Can_DeInit
 *===========================================================================*/
void Can_DeInit(void)
{
    Can_Initialized = FALSE;
    Can_CfgPtr      = NULL_PTR;
}

/*===========================================================================
 * Can_SetControllerMode
 *===========================================================================*/
Std_ReturnType Can_SetControllerMode(uint8 Controller,
                                      Can_ControllerStateType Transition)
{
    if (!Can_Initialized)                  return E_NOT_OK;
    if (Controller >= CAN_MAX_CONTROLLERS) return E_NOT_OK;

    Can_Controllers[Controller].state = Transition;

    /*
     * Real HW: set/clear HALT bit in FlexCAN MCR register
     * FlexCAN0->MCR |=  CAN_MCR_HALT_MASK;  // STOPPED
     * FlexCAN0->MCR &= ~CAN_MCR_HALT_MASK;  // STARTED
     */

    return E_OK;
}

/*===========================================================================
 * Can_Write — Queue a CAN frame for transmission
 *===========================================================================*/
Can_ReturnType Can_Write(Can_HwHandleType Hth, const Can_PduType *PduInfo)
{
    uint8 ctrl;

    if (!Can_Initialized)  return CAN_NOT_OK;
    if (PduInfo == NULL_PTR) return CAN_NOT_OK;
    if (PduInfo->length > 8U) return CAN_NOT_OK;

    /* Map HTH to controller */
    ctrl = (Hth == CAN_HTH_POWERTRAIN) ? CAN_CONTROLLER_0 : CAN_CONTROLLER_1;

    if (Can_Controllers[ctrl].state != CAN_CS_STARTED) return CAN_NOT_OK;
    if (Can_Controllers[ctrl].tx_pending >= CAN_MAX_MAILBOXES) return CAN_BUSY;

    /* Store in TX mailbox */
    uint8 mb = Can_Controllers[ctrl].tx_pending;
    Can_Controllers[ctrl].tx_id [mb] = PduInfo->id;
    Can_Controllers[ctrl].tx_len[mb] = PduInfo->length;
    memcpy(Can_Controllers[ctrl].tx_buf[mb], PduInfo->sdu, PduInfo->length);
    Can_Controllers[ctrl].tx_pending++;

    /*
     * Real HW: write to FlexCAN message buffer
     * FlexCAN0->MB[mb].CS  = CAN_CS_CODE(CAN_TX_DATA) | CAN_CS_DLC(dlc);
     * FlexCAN0->MB[mb].ID  = CAN_ID_STD(id);
     * FlexCAN0->MB[mb].WORD0 = ...
     * FlexCAN0->MB[mb].WORD1 = ...
     */

    return CAN_OK;
}

/*===========================================================================
 * Error State & Counters
 *===========================================================================*/
Std_ReturnType Can_GetControllerErrorState(uint8 ControllerId,
                                            Can_ErrorStateType *ErrorStatePtr)
{
    if (!Can_Initialized || ControllerId >= CAN_MAX_CONTROLLERS) return E_NOT_OK;
    if (ErrorStatePtr == NULL_PTR) return E_NOT_OK;

    *ErrorStatePtr = Can_Controllers[ControllerId].error_state;
    return E_OK;
}

Std_ReturnType Can_GetControllerRxErrorCounter(uint8 ControllerId,
                                                uint8 *RxErrorCounterPtr)
{
    if (!Can_Initialized || ControllerId >= CAN_MAX_CONTROLLERS) return E_NOT_OK;
    if (RxErrorCounterPtr == NULL_PTR) return E_NOT_OK;

    *RxErrorCounterPtr = Can_Controllers[ControllerId].rx_error_cnt;
    return E_OK;
}

Std_ReturnType Can_GetControllerTxErrorCounter(uint8 ControllerId,
                                                uint8 *TxErrorCounterPtr)
{
    if (!Can_Initialized || ControllerId >= CAN_MAX_CONTROLLERS) return E_NOT_OK;
    if (TxErrorCounterPtr == NULL_PTR) return E_NOT_OK;

    *TxErrorCounterPtr = Can_Controllers[ControllerId].tx_error_cnt;
    return E_OK;
}

/*===========================================================================
 * Main Functions (OS scheduled)
 *===========================================================================*/
void Can_MainFunction_Write(void)   { /* Process pending TX in polling mode */ }
void Can_MainFunction_Read(void)    { /* Check RX mailboxes */ }
void Can_MainFunction_BusOff(void)  { /* Handle bus-off recovery */ }
